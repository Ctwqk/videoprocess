/* global React */
// Inline SVG icons — minimal stroke set
const Icon = ({ d, size = 16, fill = "none", strokeWidth = 1.6, viewBox = "0 0 24 24", children, style }) => (
  <svg width={size} height={size} viewBox={viewBox} fill={fill} stroke="currentColor"
       strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" style={style}>
    {d ? <path d={d} /> : children}
  </svg>
);

const Icons = {
  spark: (p) => <Icon {...p}><path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8"/></Icon>,
  flow: (p) => <Icon {...p}><rect x="3" y="3" width="6" height="6" rx="1.4"/><rect x="15" y="15" width="6" height="6" rx="1.4"/><path d="M9 6h3a3 3 0 0 1 3 3v9"/></Icon>,
  play: (p) => <Icon {...p} fill="currentColor"><path d="M7 5v14l12-7z" stroke="none"/></Icon>,
  folder: (p) => <Icon {...p}><path d="M3 6.5A1.5 1.5 0 0 1 4.5 5h4l2 2h9A1.5 1.5 0 0 1 21 8.5v9A1.5 1.5 0 0 1 19.5 19h-15A1.5 1.5 0 0 1 3 17.5v-11Z"/></Icon>,
  layers: (p) => <Icon {...p}><path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 13 9 5 9-5"/><path d="m3 17 9 5 9-5"/></Icon>,
  search: (p) => <Icon {...p}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></Icon>,
  settings: (p) => <Icon {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3h0a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8v0a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/></Icon>,
  check: (p) => <Icon {...p}><path d="m5 12 4 4L19 7"/></Icon>,
  x: (p) => <Icon {...p}><path d="M6 6l12 12M6 18 18 6"/></Icon>,
  plus: (p) => <Icon {...p}><path d="M12 5v14M5 12h14"/></Icon>,
  upload: (p) => <Icon {...p}><path d="M12 16V4M7 9l5-5 5 5"/><path d="M5 20h14"/></Icon>,
  download: (p) => <Icon {...p}><path d="M12 4v12M7 11l5 5 5-5"/><path d="M5 20h14"/></Icon>,
  trash: (p) => <Icon {...p}><path d="M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2"/><path d="M19 6v14a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V6"/><path d="M10 11v6M14 11v6"/></Icon>,
  more: (p) => <Icon {...p}><circle cx="5" cy="12" r="1.2" fill="currentColor"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/><circle cx="19" cy="12" r="1.2" fill="currentColor"/></Icon>,
  chevron: (p) => <Icon {...p}><path d="m9 6 6 6-6 6"/></Icon>,
  pin: (p) => <Icon {...p}><path d="M12 17v5"/><path d="M9 11V4h6v7l3 3v2H6v-2l3-3Z"/></Icon>,
  film: (p) => <Icon {...p}><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 3v18M17 3v18M3 7h4M3 12h4M3 17h4M17 7h4M17 12h4M17 17h4"/></Icon>,
  music: (p) => <Icon {...p}><path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/></Icon>,
  type: (p) => <Icon {...p}><path d="M4 7V5h16v2"/><path d="M9 20h6M12 5v15"/></Icon>,
  scissors: (p) => <Icon {...p}><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="m20 4-8.5 8.5M14 14l6 6M8.1 8.1l5.9 5.9"/></Icon>,
  wand: (p) => <Icon {...p}><path d="m21 3-7 7M14 10l-9 9M15 3l-2 2 4 4 2-2-4-4Z"/></Icon>,
  globe: (p) => <Icon {...p}><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></Icon>,
  caption: (p) => <Icon {...p}><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 11h3M14 11h3M7 15h6"/></Icon>,
  zoom: (p) => <Icon {...p}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5M11 8v6M8 11h6"/></Icon>,
  zoomOut: (p) => <Icon {...p}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5M8 11h6"/></Icon>,
  fit: (p) => <Icon {...p}><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></Icon>,
  history: (p) => <Icon {...p}><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 4v4h4M12 8v4l3 2"/></Icon>,
  bell: (p) => <Icon {...p}><path d="M6 8a6 6 0 1 1 12 0c0 7 3 8 3 8H3s3-1 3-8Z"/><path d="M10 21h4"/></Icon>,
  cmd: (p) => <Icon {...p}><path d="M9 6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6Z"/></Icon>,
  copy: (p) => <Icon {...p}><rect x="8" y="8" width="13" height="13" rx="2"/><path d="M3 16V5a2 2 0 0 1 2-2h11"/></Icon>,
  rocket: (p) => <Icon {...p}><path d="M4.5 16.5C3 18 3 21 3 21s3 0 4.5-1.5"/><path d="M9 12a8 8 0 0 1 8-8h3v3a8 8 0 0 1-8 8l-2 1-2-2 1-2Z"/><circle cx="14.5" cy="9.5" r="1.2" fill="currentColor"/></Icon>,
  cube: (p) => <Icon {...p}><path d="m12 2 9 5v10l-9 5-9-5V7l9-5Z"/><path d="m3 7 9 5 9-5M12 12v10"/></Icon>,
  branch: (p) => <Icon {...p}><circle cx="6" cy="6" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="6" cy="18" r="2.5"/><path d="M6 9v6M18 8.5v.5a5 5 0 0 1-5 5H6"/></Icon>,
  list: (p) => <Icon {...p}><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/></Icon>,
  panelLeft: (p) => <Icon {...p}><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16"/></Icon>,
  share: (p) => <Icon {...p}><circle cx="6" cy="12" r="3"/><circle cx="18" cy="6" r="3"/><circle cx="18" cy="18" r="3"/><path d="m8.5 10.5 7-3M8.5 13.5l7 3"/></Icon>,
  user: (p) => <Icon {...p}><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></Icon>,
};

window.Icons = Icons;

// ============================================================
// Atoms
// ============================================================
const Badge = ({ status = "idle", children }) => {
  const map = { ok: "badge-ok", run: "badge-run", fail: "badge-fail", queue: "badge-queue", idle: "badge-idle" };
  return <span className={`badge ${map[status] || ""}`}><span className="dot"/>{children}</span>;
};

const Kbd = ({ children }) => <span className="kbd">{children}</span>;

const StatusForJob = (s) => {
  if (s === 'SUCCEEDED') return { tone: 'ok', label: 'OK' };
  if (s === 'RUNNING' || s === 'PLANNING' || s === 'VALIDATING') return { tone: 'run', label: s };
  if (s === 'FAILED' || s === 'CANCELLED') return { tone: 'fail', label: s };
  if (s === 'PENDING') return { tone: 'queue', label: 'PENDING' };
  if (s === 'PARTIALLY_FAILED') return { tone: 'fail', label: 'PARTIAL' };
  return { tone: 'idle', label: s || '—' };
};

Object.assign(window, { Badge, Kbd, StatusForJob });
