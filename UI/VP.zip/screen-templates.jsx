/* global React, Icons, Badge */

const TEMPLATES = [
  { id:'t1', name:'Short‑form compilation',  desc:'9:16 cuts from library + platform search, auto music + captions.',
    tags:['shorts','9:16','autoflow'], nodes: 8, runs: 142, lastRun:'2m ago', star: true,
    accent: 'var(--acc)' },
  { id:'t2', name:'Smart podcast trim',      desc:'Detects highlight moments and exports clipped reels with karaoke captions.',
    tags:['podcast','smart‑trim','captions'], nodes: 6, runs: 86, lastRun:'1h ago', star: true,
    accent: '#60a5fa' },
  { id:'t3', name:'Multi‑platform repost',   desc:'Render once, publish to YouTube, Bilibili, Xiaohongshu with per‑platform metadata.',
    tags:['publish','batch'], nodes: 5, runs: 64, lastRun:'yesterday',
    accent: '#c084fc' },
  { id:'t4', name:'Auto‑caption + TTS dub',  desc:'Whisper transcript → translate → XTTS dub in target language.',
    tags:['captions','tts','translate'], nodes: 7, runs: 38, lastRun:'3d ago',
    accent: '#fbbf24' },
  { id:'t5', name:'Reaction stitch',         desc:'Side‑by‑side webcam reaction overlay with auto‑sync to source video.',
    tags:['layout','overlay'], nodes: 5, runs: 22, lastRun:'5d ago',
    accent: '#f87171' },
  { id:'t6', name:'Storyboard preview',      desc:'Render only first frame of each shot as a contact sheet PDF.',
    tags:['preview','pdf'], nodes: 4, runs: 14, lastRun:'1w ago',
    accent: '#22c55e' },
];

const TemplatePreview = ({ accent }) => (
  <svg viewBox="0 0 220 88" style={{ width:'100%', height:'100%', display:'block' }}>
    <defs>
      <linearGradient id={`g-${accent.replace(/[^a-z0-9]/gi,'')}`} x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor={accent} stopOpacity="0.12" />
        <stop offset="1" stopColor={accent} stopOpacity="0" />
      </linearGradient>
    </defs>
    <rect width="220" height="88" fill={`url(#g-${accent.replace(/[^a-z0-9]/gi,'')})`} />
    {/* node graph */}
    {[
      [20, 30], [70, 18], [70, 50], [120, 30], [170, 30],
    ].map(([x,y], i) => (
      <g key={i}>
        <rect x={x} y={y} width="28" height="20" rx="3" fill="var(--bg-3)" stroke="var(--border-2)"/>
        <circle cx={x+3} cy={y+10} r="1.5" fill={accent}/>
      </g>
    ))}
    {/* edges */}
    {[[48,40,70,28],[48,40,70,60],[98,28,120,40],[98,60,120,40],[148,40,170,40]].map(([x1,y1,x2,y2],i)=>(
      <path key={i} d={`M${x1},${y1} C${(x1+x2)/2},${y1} ${(x1+x2)/2},${y2} ${x2},${y2}`}
            fill="none" stroke={accent} strokeWidth="1" strokeOpacity="0.5"/>
    ))}
  </svg>
);

const TemplatesScreen = ({ setRoute }) => {
  return (
    <div className="page">
      <div style={{ padding: '20px 24px 12px' }}>
        <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom: 14 }}>
          <h2 style={{ margin:0, fontSize:20, letterSpacing:'-0.02em', fontWeight:600 }}>Templates</h2>
          <span className="mono dim" style={{ fontSize:12 }}>·  {TEMPLATES.length} workflows  ·  shared with team</span>
          <div style={{ flex:1 }} />
          <button className="btn btn-sm"><Icons.upload size={12}/>Import</button>
          <button className="btn btn-primary"><Icons.plus size={13}/>New template</button>
        </div>

        <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom: 14 }}>
          <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
            {['all','shorts','podcast','captions','tts','publish','batch','layout','preview'].map((t,i)=>(
              <button key={t} className={`chip ${i===0?'on':''}`}>{t}</button>
            ))}
          </div>
          <div style={{ flex:1 }} />
          <div style={{ position:'relative' }}>
            <Icons.search size={13} style={{ position:'absolute', left:9, top:'50%', transform:'translateY(-50%)', color:'var(--fg-4)' }} />
            <input placeholder="Search templates…" style={{ width: 220, paddingLeft: 28 }} />
          </div>
        </div>
      </div>

      <div style={{ padding: '0 24px 24px',
                    display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(320px, 1fr))', gap: 14 }}>
        {TEMPLATES.map(t => (
          <div key={t.id} className="template-card" onClick={()=>setRoute('editor')}>
            <div className="template-mini"><TemplatePreview accent={t.accent} /></div>
            <div>
              <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom: 4 }}>
                <h3 style={{ margin:0, fontSize: 14, fontWeight: 600, letterSpacing:'-0.005em' }}>{t.name}</h3>
                {t.star && <Icons.pin size={13} style={{ color: t.accent }} />}
                <div style={{ flex:1 }}/>
                <button className="btn btn-icon btn-ghost" onClick={e=>e.stopPropagation()}><Icons.more size={14}/></button>
              </div>
              <p className="muted" style={{ fontSize: 12.5, margin: 0, lineHeight: 1.45, textWrap: 'pretty' }}>{t.desc}</p>
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:6, flexWrap:'wrap', marginTop: 'auto' }}>
              {t.tags.map(tag => <span key={tag} className="tag">{tag}</span>)}
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:14, fontSize: 11, fontFamily:'var(--font-mono)', color:'var(--fg-4)',
                          paddingTop: 10, borderTop:'1px solid var(--border-1)' }}>
              <span><span className="dim">nodes</span> · {t.nodes}</span>
              <span><span className="dim">runs</span> · {t.runs}</span>
              <span style={{ marginLeft:'auto' }} className="dim">last {t.lastRun}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

window.TemplatesScreen = TemplatesScreen;
