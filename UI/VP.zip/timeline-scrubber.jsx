/* global React, Icons */

const { useState: useStateTL, useEffect: useEffectTL, useRef: useRefTL, useCallback: useCallbackTL } = React;

// Shots with start/dur in seconds — derived from storyboard
const TIMELINE_SHOTS = [
  { i: 1, t: 'Cold open',     start: 0,  dur: 3, src: 'asset',       color: '#7dd3fc', desc: 'Wide kitten silhouette zoom in' },
  { i: 2, t: 'Beat 1',        start: 3,  dur: 5, src: 'youtube',     color: '#ef4444', desc: 'Quick cut laser chase' },
  { i: 3, t: 'Beat 2',        start: 8,  dur: 6, src: 'asset',       color: '#7dd3fc', desc: 'Wrestle pair, slo‑mo' },
  { i: 4, t: 'Reaction',      start: 14, dur: 6, src: 'bilibili',    color: '#60a5fa', desc: 'POV stare, cut to splash' },
  { i: 5, t: 'B‑roll bridge', start: 20, dur: 5, src: 'xiaohongshu', color: '#f87171', desc: 'Sleepy cat, sun flare' },
  { i: 6, t: 'Outro',         start: 25, dur: 5, src: 'asset',       color: '#7dd3fc', desc: 'Logo bug, soft fade' },
];

const TOTAL_DUR = 30;

function fmtTime(s) {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  const cs = Math.floor((s % 1) * 100);
  return `${m}:${String(sec).padStart(2,'0')}.${String(cs).padStart(2,'0')}`;
}

const TimelineScrubber = () => {
  const [time, setTime] = useStateTL(8.4); // current playhead
  const [playing, setPlaying] = useStateTL(false);
  const [hover, setHover] = useStateTL(null);
  const trackRef = useRefTL(null);
  const draggingRef = useRefTL(false);

  // play loop
  useEffectTL(() => {
    if (!playing) return;
    let id;
    const tick = (last) => (now) => {
      const dt = (now - last) / 1000;
      setTime(t => {
        const next = t + dt;
        if (next >= TOTAL_DUR) { setPlaying(false); return TOTAL_DUR; }
        return next;
      });
      id = requestAnimationFrame(tick(now));
    };
    id = requestAnimationFrame((t0) => { id = requestAnimationFrame(tick(t0)); });
    return () => cancelAnimationFrame(id);
  }, [playing]);

  const xToTime = useCallbackTL((clientX) => {
    const r = trackRef.current?.getBoundingClientRect();
    if (!r) return 0;
    const x = Math.max(0, Math.min(r.width, clientX - r.left));
    return (x / r.width) * TOTAL_DUR;
  }, []);

  const onDown = (e) => {
    draggingRef.current = true;
    setPlaying(false);
    setTime(xToTime(e.clientX));
    e.preventDefault();
    const move = (ev) => {
      if (!draggingRef.current) return;
      setTime(xToTime(ev.clientX));
    };
    const up = () => {
      draggingRef.current = false;
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  const onHover = (e) => {
    const t = xToTime(e.clientX);
    setHover({ t, x: e.clientX - (trackRef.current?.getBoundingClientRect().left || 0) });
  };

  const activeShot = TIMELINE_SHOTS.find(s => time >= s.start && time < s.start + s.dur)
                 || TIMELINE_SHOTS[TIMELINE_SHOTS.length - 1];
  const localT = Math.max(0, time - activeShot.start);
  const localProgress = Math.min(1, localT / activeShot.dur);

  // Audio waveform (deterministic pseudo-random)
  const wave = React.useMemo(() => {
    const N = 220;
    const arr = [];
    for (let i = 0; i < N; i++) {
      const v = Math.abs(Math.sin(i * 0.31) + Math.sin(i * 0.13) * 0.7 + Math.cos(i * 0.07) * 0.4);
      arr.push(0.35 + v * 0.35);
    }
    return arr;
  }, []);

  return (
    <div className="card">
      <div className="section-head">
        <h3>Timeline</h3>
        <span className="count">{TIMELINE_SHOTS.length} clips · {TOTAL_DUR}s</span>
        <div className="spacer"/>
        <button className="btn btn-sm btn-ghost"><Icons.scissors size={12}/>Split at playhead</button>
        <button className="btn btn-sm btn-ghost"><Icons.wand size={12}/>Auto‑pace</button>
        <button className="btn btn-sm btn-ghost"><Icons.history size={12}/>Markers</button>
      </div>

      <div style={{ padding: '0 20px 18px' }}>
        {/* preview + controls */}
        <div style={{ display: 'grid', gridTemplateColumns: '152px 1fr', gap: 14, marginBottom: 14 }}>
          {/* preview */}
          <div style={{ aspectRatio: '9/16', width: 152, position: 'relative',
                        borderRadius: 8, overflow: 'hidden',
                        background: 'linear-gradient(135deg,#1f1f25,#131316)',
                        border: '1px solid var(--border-2)' }}>
            <div style={{ position:'absolute', inset:10, border:'1px dashed #2a2a30', borderRadius:5 }}/>
            <div style={{ position:'absolute', top:8, left:8, display:'flex', alignItems:'center', gap:6,
                          fontSize: 10, fontFamily: 'var(--font-mono)',
                          background: 'rgba(0,0,0,0.55)', padding: '2px 6px', borderRadius: 3 }}>
              <span style={{ width:5, height:5, borderRadius:99, background: activeShot.color }} />
              <span style={{ color: 'var(--fg-2)', textTransform:'uppercase' }}>shot {String(activeShot.i).padStart(2,'0')}</span>
            </div>
            <div style={{ position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)',
                          color: 'var(--fg-3)' }}>
              <Icons.play size={28}/>
            </div>
            <div style={{ position: 'absolute', bottom: 8, left: 8, right: 8 }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9.5, color: 'var(--fg-3)',
                            background:'rgba(0,0,0,0.5)', padding: '1px 5px', borderRadius: 3,
                            display: 'inline-block' }}>
                {activeShot.t}
              </div>
              <div style={{ height: 3, marginTop: 6, background: 'rgba(0,0,0,0.5)', borderRadius: 2 }}>
                <div style={{ height: '100%', width: (localProgress * 100) + '%',
                              background: activeShot.color, borderRadius: 2 }} />
              </div>
            </div>
          </div>

          {/* controls + readout */}
          <div style={{ display:'flex', flexDirection:'column', gap: 10 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <button className="btn btn-icon"
                      onClick={()=>setTime(t => Math.max(0, (TIMELINE_SHOTS.find(s => s.start < t) || {start:0}).start ))}>
                <Icons.chevron size={14} style={{ transform:'rotate(180deg)' }}/>
              </button>
              <button className="btn btn-primary btn-icon" onClick={()=>setPlaying(p=>!p)}>
                {playing
                  ? <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/></svg>
                  : <Icons.play size={14}/>}
              </button>
              <button className="btn btn-icon"
                      onClick={()=>setTime(t => (TIMELINE_SHOTS.find(s => s.start > t) || {start: TOTAL_DUR}).start)}>
                <Icons.chevron size={14}/>
              </button>
              <span style={{ width: 1, height: 22, background: 'var(--border-2)' }} />
              <div className="mono num" style={{ fontSize: 13, color: 'var(--fg-1)' }}>
                <span style={{ color: 'var(--acc)' }}>{fmtTime(time)}</span>
                <span style={{ color: 'var(--fg-5)', margin: '0 6px' }}>/</span>
                <span style={{ color: 'var(--fg-3)' }}>{fmtTime(TOTAL_DUR)}</span>
              </div>
              <div className="muted mono" style={{ fontSize: 11, marginLeft: 10 }}>
                shot {String(activeShot.i).padStart(2,'0')} · t={localT.toFixed(2)}s · {Math.round(localProgress*100)}%
              </div>
              <div style={{ flex: 1 }} />
              <select defaultValue="1x" style={{ width: 70, padding: '4px 8px', fontSize: 11.5 }}>
                <option>0.5x</option><option>1x</option><option>1.5x</option><option>2x</option>
              </select>
              <select defaultValue="fit" style={{ width: 80, padding: '4px 8px', fontSize: 11.5 }}>
                <option value="fit">Fit 30s</option>
                <option>+50%</option><option>+100%</option>
              </select>
            </div>

            {/* time ruler */}
            <div style={{ position: 'relative', height: 22, marginTop: 4 }}>
              <svg style={{ position:'absolute', inset: 0, width: '100%', height: '100%' }} preserveAspectRatio="none">
                {Array.from({ length: TOTAL_DUR + 1 }, (_, i) => {
                  const major = i % 5 === 0;
                  const x = `${(i / TOTAL_DUR) * 100}%`;
                  return (
                    <g key={i}>
                      <line x1={x} y1={major ? 4 : 12} x2={x} y2={20}
                            stroke={major ? '#3f3f46' : '#27272a'} strokeWidth={1} />
                      {major && (
                        <text x={x} y={2} dy="0.4em"
                              fontSize="9" fill="var(--fg-4)" fontFamily="var(--font-mono)"
                              textAnchor={i===0 ? 'start' : i===TOTAL_DUR ? 'end' : 'middle'}>
                          {i}s
                        </text>
                      )}
                    </g>
                  );
                })}
              </svg>
            </div>

            {/* TRACK - clip band */}
            <div
              ref={trackRef}
              onPointerDown={onDown}
              onPointerMove={onHover}
              onPointerLeave={() => setHover(null)}
              className="scrub"
              style={{
                position: 'relative', height: 70,
                background: 'var(--bg-2)', borderRadius: 6,
                border: '1px solid var(--border-1)',
                overflow: 'hidden',
                touchAction: 'none',
                userSelect: 'none',
              }}
            >
              {/* clip blocks */}
              {TIMELINE_SHOTS.map(s => {
                const left = (s.start / TOTAL_DUR) * 100;
                const width = (s.dur / TOTAL_DUR) * 100;
                const isActive = activeShot.i === s.i;
                return (
                  <div key={s.i}
                       style={{
                         position:'absolute', top: 0, bottom: 0,
                         left: `${left}%`, width: `${width}%`,
                         background: `linear-gradient(180deg, ${s.color}22, ${s.color}11)`,
                         borderLeft: `2px solid ${s.color}`,
                         borderRight: '1px solid var(--border-1)',
                         display: 'flex', flexDirection: 'column',
                         padding: '5px 7px',
                         opacity: isActive ? 1 : 0.85,
                       }}>
                    <div style={{ display:'flex', alignItems:'center', gap: 5 }}>
                      <span className="mono" style={{ fontSize: 9, color: s.color, fontWeight: 600 }}>
                        #{String(s.i).padStart(2,'0')}
                      </span>
                      <span style={{ fontSize: 10, color: 'var(--fg-2)', whiteSpace: 'nowrap',
                                     overflow: 'hidden', textOverflow: 'ellipsis' }}>{s.t}</span>
                    </div>
                    {/* waveform */}
                    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 1,
                                  flex: 1, marginTop: 4 }}>
                      {wave.slice(Math.floor(left*2.2), Math.floor((left+width)*2.2)).map((v, i) => (
                        <div key={i} style={{
                          width: 2, height: (v * 100) + '%',
                          background: s.color, opacity: 0.6, borderRadius: 1,
                        }}/>
                      ))}
                    </div>
                    <div className="mono" style={{ fontSize: 9, color: 'var(--fg-4)', marginTop: 2 }}>
                      {s.dur}s
                    </div>
                  </div>
                );
              })}

              {/* hover line */}
              {hover && (
                <div style={{ position:'absolute', top: 0, bottom: 0,
                              left: hover.x, width: 1, background: 'rgba(255,255,255,0.18)',
                              pointerEvents: 'none' }}>
                  <div style={{ position:'absolute', top: -22, left: '50%', transform:'translateX(-50%)',
                                fontFamily: 'var(--font-mono)', fontSize: 10,
                                background: 'var(--bg-3)', border: '1px solid var(--border-2)',
                                color: 'var(--fg-2)', padding: '1px 6px', borderRadius: 3, whiteSpace: 'nowrap' }}>
                    {fmtTime(hover.t)}
                  </div>
                </div>
              )}

              {/* playhead */}
              <div style={{
                position: 'absolute', top: -4, bottom: -4,
                left: `${(time / TOTAL_DUR) * 100}%`,
                width: 2, background: 'var(--acc)',
                boxShadow: '0 0 0 1px rgba(125,211,252,0.18)',
                pointerEvents: 'none',
                zIndex: 5,
              }}>
                <div style={{ position: 'absolute', top: -6, left: '50%', transform: 'translateX(-50%)',
                              width: 0, height: 0,
                              borderLeft: '6px solid transparent', borderRight: '6px solid transparent',
                              borderTop: '6px solid var(--acc)' }}/>
                <div style={{ position: 'absolute', bottom: -6, left: '50%', transform: 'translateX(-50%)',
                              width: 0, height: 0,
                              borderLeft: '6px solid transparent', borderRight: '6px solid transparent',
                              borderBottom: '6px solid var(--acc)' }}/>
              </div>
            </div>

            {/* tracks legend */}
            <div style={{ display: 'flex', gap: 14, alignItems: 'center', fontSize: 10.5,
                          fontFamily: 'var(--font-mono)', color: 'var(--fg-4)',
                          textTransform: 'uppercase', letterSpacing: '.06em' }}>
              <span style={{ display:'flex', alignItems:'center', gap: 6 }}>
                <Icons.film size={11}/> V1 · video
              </span>
              <span style={{ display:'flex', alignItems:'center', gap: 6 }}>
                <Icons.music size={11}/> A1 · audio
              </span>
              <span style={{ display:'flex', alignItems:'center', gap: 6 }}>
                <Icons.caption size={11}/> S1 · subs
              </span>
              <span style={{ marginLeft: 'auto' }}>
                {activeShot.desc}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

window.TimelineScrubber = TimelineScrubber;
