/* global React, Icons, Badge */

const { useState: useStateA } = React;

const ASSETS = [
  { id:'a1', name:'cats_2024.mp4',           kind:'video', size:'184 MB', dur:'12:48', when:'today 11:01', tag:'library' },
  { id:'a2', name:'opening_jingle.wav',      kind:'audio', size:'2.4 MB', dur:'0:08',  when:'today 09:30', tag:'sfx' },
  { id:'a3', name:'studio_logo_bug.png',     kind:'image', size:'88 KB',  dur:'—',     when:'yesterday',   tag:'brand' },
  { id:'a4', name:'kitten_chase_4k.mov',     kind:'video', size:'612 MB', dur:'01:32', when:'yesterday',   tag:'b‑roll' },
  { id:'a5', name:'interview_raw_01.mp4',    kind:'video', size:'1.2 GB', dur:'48:12', when:'2 days ago',  tag:'raw' },
  { id:'a6', name:'subs_zh_final.srt',       kind:'sub',   size:'12 KB',  dur:'—',     when:'2 days ago',  tag:'captions' },
  { id:'a7', name:'voiceover_xtts_take3.wav',kind:'audio', size:'9.4 MB', dur:'0:42',  when:'3 days ago',  tag:'tts' },
  { id:'a8', name:'product_hero_v2.mp4',     kind:'video', size:'82 MB',  dur:'0:30',  when:'3 days ago',  tag:'final' },
  { id:'a9', name:'bgm_lofi_loop.mp3',       kind:'audio', size:'4.1 MB', dur:'2:14',  when:'last week',   tag:'bgm' },
  { id:'a10',name:'cover_thumbnail.jpg',     kind:'image', size:'412 KB', dur:'—',     when:'last week',   tag:'thumb' },
  { id:'a11',name:'demo_capture_screen.mov', kind:'video', size:'320 MB', dur:'04:22', when:'last week',   tag:'screen' },
  { id:'a12',name:'b_roll_city_dawn.mp4',    kind:'video', size:'214 MB', dur:'02:18', when:'last week',   tag:'b‑roll' },
];

const KIND_TONE = { video:'#60a5fa', audio:'#c084fc', image:'#fbbf24', sub:'var(--acc)' };
const KIND_ICON = { video: Icons.film, audio: Icons.music, image: Icons.type, sub: Icons.caption };

const AssetsScreen = () => {
  const [view, setView] = useStateA('grid');
  const [kind, setKind] = useStateA('all');
  const filtered = ASSETS.filter(a => kind === 'all' || a.kind === kind);

  return (
    <div className="page">
      <div style={{ padding: '20px 24px 12px' }}>
        <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom: 14 }}>
          <h2 style={{ margin:0, fontSize:20, letterSpacing:'-0.02em', fontWeight:600 }}>Assets</h2>
          <span className="mono dim" style={{ fontSize:12 }}>·  {ASSETS.length} items  ·  3.2 GB used / 200 GB</span>
          <div style={{ flex:1 }} />
          <div style={{ display:'flex', gap:0, padding: 3, background:'var(--bg-1)', border:'1px solid var(--border-1)', borderRadius: 7 }}>
            <button className="btn btn-sm" onClick={()=>setView('grid')} style={{ background: view==='grid'?'var(--bg-3)':'transparent', border:'1px solid '+(view==='grid'?'var(--border-2)':'transparent') }}>
              <Icons.layers size={12}/>Grid
            </button>
            <button className="btn btn-sm" onClick={()=>setView('list')} style={{ background: view==='list'?'var(--bg-3)':'transparent', border:'1px solid '+(view==='list'?'var(--border-2)':'transparent') }}>
              <Icons.list size={12}/>List
            </button>
          </div>
          <button className="btn btn-primary"><Icons.upload size={13}/>Upload</button>
        </div>

        {/* uploader */}
        <div className="uploader">
          <div className="uploader-ico"><Icons.upload size={18}/></div>
          <div style={{ flex:1 }}>
            <div style={{ fontWeight:500 }}>Drop files here, or paste a YouTube / Bilibili / Xiaohongshu URL</div>
            <div className="muted" style={{ fontSize:11.5, marginTop:2 }}>video · audio · image · .srt / .vtt / .ass — up to 4 GB per file</div>
          </div>
          <input placeholder="https://…" style={{ width: 260 }} />
          <button className="btn btn-sm"><Icons.plus size={12}/>Add by URL</button>
        </div>

        {/* filters */}
        <div style={{ display:'flex', alignItems:'center', gap:10, marginTop:14 }}>
          <div style={{ display:'flex', gap:4, padding: 3, background:'var(--bg-1)', border:'1px solid var(--border-1)', borderRadius: 7 }}>
            {[
              ['all','All', ASSETS.length],
              ['video','Video', ASSETS.filter(a=>a.kind==='video').length],
              ['audio','Audio', ASSETS.filter(a=>a.kind==='audio').length],
              ['image','Image', ASSETS.filter(a=>a.kind==='image').length],
              ['sub','Subs',  ASSETS.filter(a=>a.kind==='sub').length],
            ].map(([k,l,n])=>(
              <button key={k} className="btn btn-sm" onClick={()=>setKind(k)}
                      style={{
                        background: kind===k ? 'var(--bg-3)' : 'transparent',
                        border: '1px solid ' + (kind===k ? 'var(--border-2)' : 'transparent'),
                        color: kind===k ? 'var(--fg-1)' : 'var(--fg-3)',
                      }}>
                {l} <span className="mono dim" style={{ marginLeft:6, fontSize:10.5 }}>{n}</span>
              </button>
            ))}
          </div>
          <div style={{ flex:1 }} />
          <div style={{ position:'relative' }}>
            <Icons.search size={13} style={{ position:'absolute', left:9, top:'50%', transform:'translateY(-50%)', color:'var(--fg-4)' }} />
            <input placeholder="Search assets…" style={{ width: 240, paddingLeft: 28 }} />
          </div>
          <select defaultValue="recent" style={{ width: 150 }}>
            <option value="recent">Sort · newest</option>
            <option>Sort · largest</option>
            <option>Sort · name</option>
          </select>
        </div>
      </div>

      {view === 'grid' ? (
        <div className="assets-grid">
          {filtered.map(a => {
            const I = KIND_ICON[a.kind] || Icons.cube;
            return (
              <div key={a.id} className="asset-card">
                <div className="asset-thumb" style={{ display:'grid', placeItems:'center' }}>
                  <I size={28} style={{ color: KIND_TONE[a.kind], opacity:0.5 }} />
                  <span className="kind" style={{ color: KIND_TONE[a.kind] }}>{a.kind}</span>
                  {a.dur !== '—' && <span className="dur">{a.dur}</span>}
                </div>
                <div className="asset-info">
                  <div className="asset-name">{a.name}</div>
                  <div className="asset-meta">
                    <span>{a.size}</span>
                    <span>·</span>
                    <span>{a.when}</span>
                    <span style={{ marginLeft:'auto' }} className="tag">{a.tag}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div style={{ padding: '0 24px 24px' }}>
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th style={{ width: 90 }}>Kind</th>
                <th style={{ width: 90 }}>Size</th>
                <th style={{ width: 90 }}>Duration</th>
                <th style={{ width: 130 }}>Uploaded</th>
                <th style={{ width: 100 }}>Tag</th>
                <th style={{ width: 110 }} className="actions">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(a => {
                const I = KIND_ICON[a.kind] || Icons.cube;
                return (
                  <tr key={a.id}>
                    <td>
                      <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                        <I size={14} style={{ color: KIND_TONE[a.kind] }} />
                        <span className="row-link">{a.name}</span>
                      </div>
                    </td>
                    <td className="mono dim" style={{ fontSize:11.5, textTransform:'uppercase' }}>{a.kind}</td>
                    <td className="mono dim" style={{ fontSize:12 }}>{a.size}</td>
                    <td className="mono dim" style={{ fontSize:12 }}>{a.dur}</td>
                    <td className="mono dim" style={{ fontSize:12 }}>{a.when}</td>
                    <td><span className="tag">{a.tag}</span></td>
                    <td className="actions">
                      <button className="btn btn-icon btn-ghost"><Icons.download size={13}/></button>
                      <button className="btn btn-icon btn-ghost"><Icons.more size={13}/></button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

window.AssetsScreen = AssetsScreen;
