/* global React, Icons, Badge */

const { useState } = React;

const SAMPLE_PROMPT = `30秒猫咪集锦短视频，竖屏9:16，节奏轻快可爱，结尾留3秒缓动镜头，先生成预览不要公开发布。`;

const CANDIDATES = [
  { id: 'c1', title: 'Ginger kitten chasing laser dot', src: 'youtube', author: '@curiouspaws', dur: '00:08', rights: 'allowed', selected: true, locked: false, score: 0.92 },
  { id: 'c2', title: 'Two black kittens wrestle on couch', src: 'asset', author: 'Library / Cats2024', dur: '00:11', rights: 'allowed', selected: true, locked: true, score: 0.88 },
  { id: 'c3', title: 'Sleeping cat side angle b‑roll', src: 'xiaohongshu', author: '@nekomura', dur: '00:06', rights: 'review_required', selected: true, locked: false, score: 0.79 },
  { id: 'c4', title: 'Cat staring camera POV studio shot', src: 'bilibili', author: 'UP主 / 喵星人TV', dur: '00:04', rights: 'allowed', selected: true, locked: false, score: 0.74 },
  { id: 'c5', title: 'Kitten paw splash slow‑mo', src: 'youtube', author: '@slow_paws', dur: '00:09', rights: 'allowed', selected: false, locked: false, score: 0.61 },
];

const STORYBOARD = [
  { i: 1, t: 'Cold open',     dur: '0:00–0:03', desc: 'Wide kitten silhouette zoom in, beat drop' },
  { i: 2, t: 'Beat 1',        dur: '0:03–0:08', desc: 'Quick cut laser chase, whip pan' },
  { i: 3, t: 'Beat 2',        dur: '0:08–0:14', desc: 'Wrestle pair, slo‑mo bounce' },
  { i: 4, t: 'Reaction',      dur: '0:14–0:20', desc: 'POV stare, cut to splash' },
  { i: 5, t: 'B‑roll bridge', dur: '0:20–0:25', desc: 'Sleepy cat, sun flare overlay' },
  { i: 6, t: 'Outro',         dur: '0:25–0:30', desc: 'Logo bug, soft fade' },
];

const PLATFORM_DOT = { youtube: '#ef4444', bilibili: '#60a5fa', xiaohongshu: '#f87171', asset: '#c4f74a', x: '#a1a1aa' };

const Pill = ({ children, on, onClick }) => (
  <button type="button" className={`chip ${on?'on':''}`} onClick={onClick}>{children}</button>
);

const KV = ({ k, v }) => <><dt>{k}</dt><dd>{v}</dd></>;

const AutoFlowScreen = ({ setRoute, setActiveJob }) => {
  const [prompt, setPrompt] = useState(SAMPLE_PROMPT);
  const [ratio, setRatio] = useState('9:16');
  const [dur, setDur] = useState(30);
  const [publishMode, setPublishMode] = useState('preview_only');
  const [sources, setSources] = useState({ youtube:true, bilibili:true, xiaohongshu:true, x:false });
  const [planning, setPlanning] = useState(false);
  const [planned, setPlanned] = useState(true); // start with plan visible
  const [selectedCands, setSelectedCands] = useState(Object.fromEntries(CANDIDATES.map(c=>[c.id,c.selected])));
  const [approved, setApproved] = useState(false);

  const generate = () => {
    setPlanning(true); setPlanned(false); setApproved(false);
    setTimeout(()=>{ setPlanning(false); setPlanned(true); }, 1400);
  };

  const selectedCount = Object.values(selectedCands).filter(Boolean).length;

  return (
    <div className="page" style={{ padding: '20px 24px 32px', gap: 18, display:'flex', flexDirection:'column' }}>
      {/* Prompt shell */}
      <div className="prompt-shell">
        <div style={{ display:'flex', alignItems:'center', gap:10, color:'var(--fg-3)', fontSize:11.5, textTransform:'uppercase', letterSpacing:'.08em', fontFamily:'var(--font-mono)' }}>
          <Icons.spark size={13} style={{ color:'var(--acc)' }} /> AutoFlow planner
          <span style={{ marginLeft:'auto', display:'flex', gap:8, alignItems:'center' }}>
            <span className="tag">claude‑sonnet‑4.5</span>
            <span className="tag">graph_planning · auto</span>
          </span>
        </div>
        <textarea className="prompt-text" value={prompt} onChange={e=>setPrompt(e.target.value)} />
        <div className="prompt-row">
          <Pill on={ratio==='9:16'} onClick={()=>setRatio('9:16')}>9:16 vertical</Pill>
          <Pill on={ratio==='16:9'} onClick={()=>setRatio('16:9')}>16:9 horizontal</Pill>
          <Pill on={ratio==='1:1'} onClick={()=>setRatio('1:1')}>1:1 square</Pill>
          <span style={{ width:1, height:18, background:'var(--border-2)' }} />
          <Pill>{dur}s duration</Pill>
          <Pill>3–8 shots</Pill>
          <span style={{ width:1, height:18, background:'var(--border-2)' }} />
          {Object.entries(sources).map(([k,v])=>(
            <Pill key={k} on={v} onClick={()=>setSources(s=>({...s,[k]:!s[k]}))}>
              <span style={{ width:6, height:6, borderRadius:99, background: PLATFORM_DOT[k], display:'inline-block' }} /> {k}
            </Pill>
          ))}
          <div style={{ flex:1 }} />
          <Pill on={publishMode==='preview_only'} onClick={()=>setPublishMode('preview_only')}>preview only</Pill>
          <Pill on={publishMode==='private_upload'} onClick={()=>setPublishMode('private_upload')}>private upload</Pill>
          <Pill on={publishMode==='unlisted_upload'} onClick={()=>setPublishMode('unlisted_upload')}>unlisted</Pill>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <button className="btn-ghost btn btn-sm"><Icons.history size={12}/>History</button>
          <button className="btn-ghost btn btn-sm"><Icons.layers size={12}/>Load template</button>
          <div style={{ flex:1 }} />
          <span className="muted mono" style={{ fontSize: 11 }}>est. cost · $0.18 · ~38s</span>
          <button className="btn btn-primary" onClick={generate} disabled={planning}>
            <Icons.spark size={13}/> {planning ? 'Planning…' : (planned ? 'Re‑plan' : 'Generate plan')}
          </button>
        </div>
      </div>

      {/* Review gate */}
      {planned && (
        <div className="gate">
          {approved ? <Icons.check size={18} style={{ color:'var(--status-ok)' }} /> : <span className="pulse" />}
          <div>
            <div className="gate-title">{approved ? 'Plan approved — ready to execute' : 'Human review required'}</div>
            <div className="gate-sub">
              {approved ? 'rights cleared · 5/5 candidates allowed · publishing as private_upload' :
                          'rights audit: 4 allowed / 1 review_required · approve to enable Execute'}
            </div>
          </div>
          <div className="gate-actions">
            <button className="btn btn-sm" onClick={()=>setApproved(false)}><Icons.x size={12}/>Reject</button>
            <button className="btn btn-sm" onClick={()=>setApproved(a=>!a)}><Icons.check size={12}/>{approved? 'Unapprove' : 'Approve plan'}</button>
            <button className="btn btn-primary btn-sm" disabled={!approved}
                    onClick={()=>{ setActiveJob('j-8a3f'); setRoute('job-detail'); }}>
              <Icons.rocket size={12}/> Execute
            </button>
          </div>
        </div>
      )}

      {/* Main plan area */}
      {planned && (
        <div style={{ display:'grid', gridTemplateColumns:'1.4fr 1fr', gap:18, alignItems:'start' }}>
          {/* LEFT — intent + storyboard */}
          <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
            <div className="card">
              <div className="section-head">
                <h3>Resolved intent</h3>
                <span className="count">plan_2f9c · v3</span>
                <div className="spacer"/>
                <button className="btn btn-sm btn-ghost"><Icons.copy size={12}/>Copy JSON</button>
              </div>
              <dl className="kv-grid">
                <KV k="goal"           v="cat compilation, cute fast‑paced" />
                <KV k="duration"       v={<span className="mono">30.0s · target ±2s</span>} />
                <KV k="aspect"         v={<span className="mono">9:16 · 1080×1920</span>} />
                <KV k="shot count"     v={<span className="mono">6 of 3–8</span>} />
                <KV k="source policy"  v="owned_only + 3 platforms" />
                <KV k="publish"        v={<><Badge status="queue">{publishMode}</Badge> <span className="muted" style={{marginLeft:6, fontSize:11.5}}>default private per project rules</span></>} />
              </dl>
            </div>

            <div className="card">
              <div className="section-head">
                <h3>Storyboard</h3>
                <span className="count">{STORYBOARD.length} shots</span>
                <div className="spacer"/>
                <button className="btn btn-sm btn-ghost"><Icons.plus size={12}/>Insert shot</button>
                <button className="btn btn-sm btn-ghost"><Icons.wand size={12}/>Auto‑pace</button>
              </div>
              <div className="story">
                {STORYBOARD.map(s => (
                  <div key={s.i} className="story-shot">
                    <div className="frame">
                      <span className="ix">#{String(s.i).padStart(2,'0')}</span>
                      <span className="dur">{s.dur.split('–')[1]}</span>
                    </div>
                    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginTop:8 }}>
                      <span style={{ fontSize:11.5, fontWeight:600 }}>{s.t}</span>
                      <span className="mono" style={{ fontSize:10, color:'var(--fg-4)' }}>{s.dur}</span>
                    </div>
                    <div className="desc">{s.desc}</div>
                  </div>
                ))}
              </div>
            </div>

            <TimelineScrubber />

            <div className="card">
              <div className="section-head">
                <h3>Workflow preview</h3>
                <span className="count">8 nodes · 9 edges</span>
                <div className="spacer"/>
                <button className="btn btn-sm" onClick={()=>setRoute('editor')}><Icons.flow size={12}/>Open in editor</button>
              </div>
              <div style={{ padding:'4px 20px 20px' }}>
                <MiniGraph />
              </div>
            </div>
          </div>

          {/* RIGHT — metadata + candidates + rights */}
          <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
            <div className="card">
              <div className="section-head">
                <h3>Rights audit</h3>
                <span className="count">{selectedCount}/{CANDIDATES.length} sources</span>
              </div>
              <div style={{ padding:'4px 20px 18px', display:'flex', flexDirection:'column', gap:10 }}>
                <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                  <div className="meter ok" style={{ flex:1 }}><div style={{ width:'80%' }}/></div>
                  <span className="mono" style={{ fontSize:11, color:'var(--fg-3)' }}>80% allowed</span>
                </div>
                <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
                  <Badge status="ok">4 allowed</Badge>
                  <Badge status="run">1 review</Badge>
                  <Badge status="fail">0 blocked</Badge>
                  <Badge status="queue">execute ✓</Badge>
                  <Badge status="idle">publish · private</Badge>
                </div>
              </div>
            </div>

            <div className="card">
              <div className="section-head">
                <h3>Title & metadata</h3>
                <div className="spacer"/>
                <button className="btn btn-sm btn-ghost"><Icons.wand size={12}/>Regenerate</button>
              </div>
              <div style={{ padding:'0 20px 18px', display:'flex', flexDirection:'column', gap:10 }}>
                <input defaultValue="Tiny chaos · cat compilation for tired humans" />
                <textarea rows={3} defaultValue="A 30‑second pocket of pure feline mischief — sourced from creator library and three platforms, cleared for private upload." style={{ resize:'vertical' }} />
                <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>
                  {['#cats','#shorts','#fyp','#asmr','#cute','+ add'].map((t,i)=>(
                    <span key={i} className="tag" style={{ cursor:'pointer' }}>{t}</span>
                  ))}
                </div>
              </div>
            </div>

            <div className="card">
              <div className="section-head">
                <h3>Candidate clips</h3>
                <span className="count">{selectedCount} selected</span>
                <div className="spacer"/>
                <button className="btn btn-sm btn-ghost"><Icons.plus size={12}/>Add</button>
              </div>
              <div style={{ padding:'0 14px 14px', display:'flex', flexDirection:'column', gap:8 }}>
                {CANDIDATES.map(c => (
                  <div key={c.id} className={`clip ${selectedCands[c.id]?'selected':''}`}>
                    <div className="clip-thumb" data-dur={c.dur} />
                    <div className="clip-meta">
                      <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                        <span className="dot" style={{ width:6, height:6, borderRadius:99, background: PLATFORM_DOT[c.src], display:'inline-block' }} />
                        <span className="mono dim" style={{ fontSize:10.5, textTransform:'uppercase', letterSpacing:'.06em' }}>{c.src}</span>
                        {c.rights === 'review_required'
                          ? <Badge status="run">REVIEW</Badge>
                          : <Badge status="ok">ALLOWED</Badge>}
                        {c.locked ? <span className="tag"><Icons.pin size={10} style={{ marginRight:4 }}/>locked</span> : null}
                        <span className="mono dim" style={{ marginLeft:'auto', fontSize:11 }}>score {c.score.toFixed(2)}</span>
                      </div>
                      <p className="clip-title" style={{ marginTop:4 }}>{c.title}</p>
                      <p className="clip-sub">{c.author}</p>
                    </div>
                    <input type="checkbox" checked={!!selectedCands[c.id]}
                           onChange={()=>setSelectedCands(s=>({...s,[c.id]:!s[c.id]}))}
                           style={{ width:16, height:16, accentColor:'var(--acc)' }} />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {planning && (
        <div className="card" style={{ padding:18, display:'flex', gap:14, alignItems:'center' }}>
          <span className="pulse" style={{ background:'var(--acc)' }}/>
          <div>
            <div style={{ fontWeight:600 }}>Planning workflow…</div>
            <div className="muted mono" style={{ fontSize:11.5, marginTop:2 }}>resolving intent · evaluating capabilities · assembling DAG</div>
          </div>
        </div>
      )}

      {!planned && !planning && (
        <div className="empty">
          <div className="ico"><Icons.spark size={22}/></div>
          <div style={{ fontSize:14, color:'var(--fg-2)', marginBottom:4 }}>Describe the video you want.</div>
          <div className="muted" style={{ fontSize:12.5 }}>AutoFlow turns it into a reviewable pipeline with rights, storyboard, and metadata.</div>
        </div>
      )}
    </div>
  );
};

// tiny inline graph preview
const MiniGraph = () => {
  const nodes = [
    { x: 10,  y: 10, t: 'AssetFetch',    k: 'source', s: 'ok' },
    { x: 10,  y: 80, t: 'PlatformSearch', k: 'source', s: 'ok' },
    { x: 180, y: 45, t: 'RightsFilter',  k: 'gate',   s: 'ok' },
    { x: 340, y: 10, t: 'ShotSelector',  k: 'plan',   s: 'ok' },
    { x: 340, y: 80, t: 'AutoCaption',   k: 'media',  s: 'ok' },
    { x: 510, y: 45, t: 'Assemble',      k: 'render', s: 'run' },
    { x: 670, y: 45, t: 'Publish',       k: 'export', s: 'idle' },
  ];
  const edges = [[0,2],[1,2],[2,3],[2,4],[3,5],[4,5],[5,6]];
  const tone = { ok:'var(--status-ok)', run:'var(--status-run)', idle:'var(--fg-5)' };
  return (
    <div style={{ position:'relative', height: 160, background: 'var(--bg-2)', border:'1px solid var(--border-1)', borderRadius:8, overflow:'hidden' }}>
      <svg style={{ position:'absolute', inset:0, width:'100%', height:'100%' }}>
        {edges.map(([a,b],i)=>{
          const A = nodes[a], B = nodes[b];
          const x1 = A.x+110, y1 = A.y+18, x2 = B.x, y2 = B.y+18;
          const mx = (x1+x2)/2;
          return <path key={i} d={`M${x1},${y1} C${mx},${y1} ${mx},${y2} ${x2},${y2}`} fill="none" stroke="var(--border-3)" strokeWidth={1.2} />;
        })}
      </svg>
      {nodes.map((n,i)=>(
        <div key={i} style={{ position:'absolute', left:n.x, top:n.y, width:110, padding:'6px 8px',
                              background:'var(--bg-3)', border:'1px solid var(--border-2)', borderRadius:6,
                              fontSize:10.5, fontFamily:'var(--font-mono)' }}>
          <div style={{ display:'flex', alignItems:'center', gap:6 }}>
            <span style={{ width:5, height:5, borderRadius:99, background: tone[n.s] }} />
            <span style={{ color:'var(--fg-1)', fontWeight:600 }}>{n.t}</span>
          </div>
          <div style={{ color:'var(--fg-5)', marginTop:2, fontSize:9.5, textTransform:'uppercase' }}>{n.k}</div>
        </div>
      ))}
    </div>
  );
};

window.AutoFlowScreen = AutoFlowScreen;
