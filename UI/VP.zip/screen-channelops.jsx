/* global React, Icons, Badge */

const { useState: useStateCO } = React;

const CHANNELS = [
  { id: 'ch-asmrcats', name: 'ASMR Cats EN',   lang: 'en',    dry: false, halted: false, version: 12, active: 2, queued: 14, fails: 0,  warnings: 0 },
  { id: 'ch-petcomp',  name: 'Pet Compilations CN', lang: 'zh', dry: true,  halted: false, version: 8,  active: 0, queued: 6,  fails: 1,  warnings: 2 },
  { id: 'ch-shorts',   name: 'Cooking Shorts',  lang: 'en/zh', dry: false, halted: true,  version: 5,  active: 0, queued: 0,  fails: 3,  warnings: 1 },
];

const FUNNEL = [
  { stage: 'prompted',       value: 142 },
  { stage: 'planned',        value: 128 },
  { stage: 'rights_cleared', value: 96 },
  { stage: 'rendered',       value: 88 },
  { stage: 'uploaded',       value: 82 },
  { stage: 'published',      value: 71 },
];

const LANES = [
  { id: 'la-prod',    name: 'Production',    state: 'active' },
  { id: 'la-rights',  name: 'Rights review', state: 'active' },
  { id: 'la-publish', name: 'Publish queue', state: 'paused' },
];

const ACCOUNTS = [
  { id: 'a1', label: '@asmrcats',      platform: 'youtube',     state: 'active'  },
  { id: 'a2', label: 'asmr_cats_jp',   platform: 'xiaohongshu', state: 'active'  },
  { id: 'a3', label: 'UID_29384',     platform: 'bilibili',    state: 'paused'  },
  { id: 'a4', label: '@catteryclips',  platform: 'x',           state: 'token_invalid' },
];

const QUEUE = [
  { id:'q-9af2', kind:'plan',        priority:5, status:'queued',  attempts:0, payload:'cat compilation · 9:16 · 30s' },
  { id:'q-9ad0', kind:'render',      priority:7, status:'claimed', attempts:1, payload:'pipeline_b41e · job j-8a3f' },
  { id:'q-9a31', kind:'publish',     priority:9, status:'held',    attempts:0, payload:'video_id=cAB91 · private→unlisted' },
  { id:'q-99fa', kind:'rights_eval', priority:6, status:'running', attempts:0, payload:'plan_2f9c · 5 candidates' },
  { id:'q-99e4', kind:'plan',        priority:5, status:'failed',  attempts:3, payload:'travel vlog · timeout 30s' },
];

const PUBLICATIONS = [
  { id:'p-7711', task:'tk-411a', platform:'youtube',     title:'Tiny chaos · cat compilation',  privacy:'private',  desired:'unlisted', state:'uploaded_private', warnings:[] },
  { id:'p-7710', task:'tk-410d', platform:'xiaohongshu', title:'晨间猫咪日常',                    privacy:'public',   desired:'public',   state:'published',        warnings:[] },
  { id:'p-770f', task:'tk-410d', platform:'bilibili',    title:'晨间猫咪日常',                    privacy:'unlisted', desired:'public',   state:'scheduled',        warnings:['cover_pending'] },
  { id:'p-770e', task:'tk-410a', platform:'youtube',     title:'B‑roll · city dawn',             privacy:'public',   desired:'public',   state:'failed',           warnings:['quota_exceeded'] },
];

const STATE_TONE = {
  active: 'ok', running: 'run', completed: 'ok', succeeded: 'ok',
  queued: 'queue', claimed: 'queue', pending: 'queue',
  failed: 'fail', dead_lettered: 'fail',
  held: 'run', paused: 'run', uploaded_private: 'run', token_invalid: 'fail',
  scheduled: 'ok', published: 'ok', disabled: 'idle',
};

const ChannelOpsScreen = () => {
  const [ch, setCh] = useStateCO(CHANNELS[0].id);
  const [tab, setTab] = useStateCO('queue');
  const channel = CHANNELS.find(c => c.id === ch);

  return (
    <div className="page">
      {/* Channel selector strip */}
      <div style={{ padding: '20px 24px 0' }}>
        <div style={{ display:'flex', alignItems:'center', gap: 10, marginBottom: 14 }}>
          <h2 style={{ margin:0, fontSize: 20, fontWeight: 600, letterSpacing:'-0.02em' }}>ChannelOps</h2>
          <span className="muted mono" style={{ fontSize: 12 }}>
            · {channel.name} · lang {channel.lang} · config v{channel.version}
          </span>
          <div style={{ flex:1 }} />
          <select value={ch} onChange={e=>setCh(e.target.value)} style={{ width: 220 }}>
            {CHANNELS.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <button className="btn btn-sm"><Icons.history size={12}/>Refresh · 10s</button>
          <button className="btn btn-sm" style={{
            color: channel.dry ? 'var(--status-run)' : 'var(--fg-2)' }}>
            {channel.dry ? <Icons.play size={12}/> : <Icons.x size={12}/>}
            {channel.dry ? 'Enable live' : 'Switch to dry‑run'}
          </button>
          {channel.halted
            ? <button className="btn btn-primary btn-sm"><Icons.play size={12}/>Resume</button>
            : <button className="btn btn-sm btn-danger"><Icons.x size={12}/>Halt channel</button>}
        </div>

        {/* status pills */}
        <div style={{ display:'flex', gap: 8, marginBottom: 14 }}>
          <Badge status={channel.dry ? 'run' : 'ok'}>{channel.dry ? 'DRY‑RUN' : 'LIVE'}</Badge>
          <Badge status={channel.halted ? 'fail' : 'ok'}>{channel.halted ? 'HALTED' : 'RUNNING'}</Badge>
          {channel.halted && <span className="muted" style={{ fontSize:12, fontFamily:'var(--font-mono)' }}>reason: operator_halt · 14m ago</span>}
        </div>

        {/* stats */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap: 12, marginBottom: 18 }}>
          <Kpi label="Active tasks"    value={channel.active}   tone="queue" sub="2 running on runner-01" />
          <Kpi label="Queued items"    value={channel.queued}   tone="idle"  sub="oldest 2m · priority avg 6.2" />
          <Kpi label="Recent failures" value={channel.fails}    tone={channel.fails>0?'fail':'ok'} sub="last 24h · 1 quota · 0 timeout" />
          <Kpi label="Warnings"        value={channel.warnings} tone={channel.warnings>0?'run':'ok'} sub="cover_pending · low‑confidence captions" />
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1.4fr 1fr', gap: 18, padding:'0 24px 24px' }}>
        {/* LEFT — funnel + tabs */}
        <div style={{ display:'flex', flexDirection:'column', gap: 14 }}>
          {/* funnel */}
          <div className="card">
            <div className="section-head">
              <h3>7‑day funnel</h3>
              <span className="count">{channel.name}</span>
              <div className="spacer"/>
              <button className="btn btn-sm btn-ghost"><Icons.download size={12}/>Export</button>
            </div>
            <div style={{ padding:'4px 20px 20px', display:'flex', flexDirection:'column', gap: 10 }}>
              {FUNNEL.map((f, i) => {
                const pct = (f.value / FUNNEL[0].value) * 100;
                const drop = i > 0 ? ((FUNNEL[i-1].value - f.value) / FUNNEL[i-1].value) * 100 : 0;
                return (
                  <div key={f.stage} style={{ display:'grid', gridTemplateColumns:'130px 1fr 80px', gap: 14, alignItems:'center' }}>
                    <span className="mono dim" style={{ fontSize:11, textTransform:'uppercase', letterSpacing:'.05em' }}>{f.stage}</span>
                    <div style={{ position:'relative', height: 26, background:'var(--bg-2)', borderRadius: 4, overflow:'hidden' }}>
                      <div style={{
                        position:'absolute', left:0, top:0, bottom:0,
                        width: pct + '%',
                        background: 'linear-gradient(90deg, var(--acc) 0%, var(--acc-2) 100%)',
                        opacity: 0.85 - i * 0.1,
                      }}/>
                      <span style={{ position:'absolute', left:10, top: '50%', transform:'translateY(-50%)',
                                     fontSize:11.5, fontFamily:'var(--font-mono)', color:'var(--acc-fg)',
                                     fontWeight: 600, mixBlendMode:'screen' }}>
                        {pct.toFixed(0)}%
                      </span>
                    </div>
                    <div style={{ textAlign:'right' }}>
                      <span className="mono" style={{ fontVariantNumeric:'tabular-nums' }}>{f.value}</span>
                      {drop > 0 && <span className="muted mono" style={{ fontSize:10.5, marginLeft:6 }}>−{drop.toFixed(0)}%</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* tabbed work list */}
          <div className="card">
            <div className="section-head">
              <h3>Work</h3>
              <div className="spacer"/>
              <div style={{ display:'flex', gap: 2, padding: 3,
                            background:'var(--bg-2)', border:'1px solid var(--border-1)', borderRadius: 7 }}>
                {[
                  ['queue', 'Queue', QUEUE.length],
                  ['tasks', 'Tasks', 24],
                  ['pubs',  'Publications', PUBLICATIONS.length],
                ].map(([k,l,n])=>(
                  <button key={k} className="btn btn-sm" onClick={()=>setTab(k)}
                          style={{
                            background: tab===k ? 'var(--bg-3)' : 'transparent',
                            border: '1px solid ' + (tab===k ? 'var(--border-2)' : 'transparent'),
                            color: tab===k ? 'var(--fg-1)' : 'var(--fg-3)',
                          }}>
                    {l} <span className="mono dim" style={{ marginLeft:6, fontSize:10.5 }}>{n}</span>
                  </button>
                ))}
              </div>
            </div>

            {tab === 'queue' && (
              <table className="table" style={{ marginBottom: 6 }}>
                <thead>
                  <tr>
                    <th style={{ width: 110 }}>ID</th>
                    <th style={{ width: 110 }}>Kind</th>
                    <th>Payload</th>
                    <th style={{ width: 70 }}>Prio</th>
                    <th style={{ width: 100 }}>Status</th>
                    <th style={{ width: 70 }}>Attempts</th>
                  </tr>
                </thead>
                <tbody>
                  {QUEUE.map(q => (
                    <tr key={q.id}>
                      <td className="id">{q.id}</td>
                      <td><span className="tag">{q.kind}</span></td>
                      <td className="muted" style={{ fontSize: 12 }}>{q.payload}</td>
                      <td className="mono">{q.priority}</td>
                      <td><Badge status={STATE_TONE[q.status]||'idle'}>{q.status}</Badge></td>
                      <td className="mono dim">{q.attempts}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

            {tab === 'pubs' && (
              <table className="table">
                <thead>
                  <tr>
                    <th style={{ width: 90 }}>ID</th>
                    <th style={{ width: 110 }}>Platform</th>
                    <th>Title</th>
                    <th style={{ width: 130 }}>Privacy</th>
                    <th style={{ width: 130 }}>State</th>
                    <th style={{ width: 130 }}>Warnings</th>
                  </tr>
                </thead>
                <tbody>
                  {PUBLICATIONS.map(p => (
                    <tr key={p.id}>
                      <td className="id">{p.id}</td>
                      <td><span className="tag">{p.platform}</span></td>
                      <td><span className="row-link">{p.title}</span></td>
                      <td className="muted mono" style={{ fontSize: 12 }}>
                        {p.privacy} <span style={{ color: 'var(--fg-5)' }}>→</span> {p.desired}
                      </td>
                      <td><Badge status={STATE_TONE[p.state]||'idle'}>{p.state}</Badge></td>
                      <td>{p.warnings.length === 0
                        ? <span className="dim mono" style={{ fontSize:11 }}>—</span>
                        : p.warnings.map(w => <span key={w} className="tag" style={{ color:'var(--status-run)' }}>{w}</span>)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

            {tab === 'tasks' && (
              <div style={{ padding: '0 20px 20px' }}>
                {[
                  ['tk-411a','planning','Quick cat moments compilation #14','—'],
                  ['tk-410d','rendering','晨间猫咪日常 #11','—'],
                  ['tk-410b','blocked','Travel vlog snippet','rights:review'],
                  ['tk-410a','published','B‑roll · city dawn','—'],
                ].map(([id,s,p,b]) => (
                  <div key={id} style={{
                    display:'grid', gridTemplateColumns:'120px 1fr 130px 130px', gap: 14,
                    padding: '12px 0', borderBottom: '1px solid var(--border-1)', fontSize: 12.5,
                  }}>
                    <span className="mono dim">{id}</span>
                    <span>{p}</span>
                    <Badge status={STATE_TONE[s]||'idle'}>{s}</Badge>
                    <span className="mono dim" style={{ fontSize: 11.5 }}>{b}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* RIGHT — Lanes + accounts + warnings */}
        <div style={{ display:'flex', flexDirection:'column', gap: 14 }}>
          <div className="card">
            <div className="section-head">
              <h3>Warnings</h3>
              <span className="count">{channel.warnings}</span>
              <div className="spacer"/>
              <button className="btn btn-sm btn-ghost">Acknowledge all</button>
            </div>
            <div style={{ padding:'0 20px 16px', display:'flex', flexDirection:'column', gap: 8 }}>
              {channel.warnings === 0
                ? <div className="muted" style={{ fontSize: 12 }}>All clear.</div>
                : (
                  <>
                    <WarningRow tone="run"  msg="2 publications stuck in scheduled > 24h" id="cover_pending · bilibili" />
                    <WarningRow tone="fail" msg="@catteryclips token check failed" id="account:a4 · 4h ago" />
                  </>
                )}
            </div>
          </div>

          <div className="card">
            <div className="section-head"><h3>Lanes</h3><span className="count">{LANES.length}</span></div>
            <div style={{ padding: '0 20px 18px', display:'flex', flexDirection:'column', gap: 8 }}>
              {LANES.map(l => (
                <div key={l.id} style={{ display:'flex', alignItems:'center', gap: 10, padding:'9px 0',
                                          borderBottom: '1px solid var(--border-1)' }}>
                  <div>
                    <div style={{ fontWeight: 500, fontSize: 13 }}>{l.name}</div>
                    <div className="muted mono" style={{ fontSize: 11 }}>{l.id}</div>
                  </div>
                  <div style={{ flex:1 }} />
                  <Badge status={STATE_TONE[l.state]||'idle'}>{l.state}</Badge>
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <div className="section-head"><h3>Accounts</h3><span className="count">{ACCOUNTS.length}</span></div>
            <div style={{ padding: '0 20px 18px', display:'flex', flexDirection:'column', gap: 8 }}>
              {ACCOUNTS.map(a => (
                <div key={a.id} style={{ display:'flex', alignItems:'center', gap: 10, padding:'9px 0',
                                          borderBottom: '1px solid var(--border-1)' }}>
                  <div>
                    <div style={{ fontWeight: 500, fontSize: 13 }}>{a.label}</div>
                    <div className="muted mono" style={{ fontSize: 11 }}>{a.platform}</div>
                  </div>
                  <div style={{ flex:1 }} />
                  <Badge status={STATE_TONE[a.state]||'idle'}>{a.state}</Badge>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Kpi = ({ label, value, tone, sub }) => {
  const c = { ok:'var(--status-ok)', run:'var(--status-run)', fail:'var(--status-fail)', queue:'var(--status-queue)', idle:'var(--fg-5)' }[tone];
  return (
    <div className="card" style={{ padding: '14px 18px' }}>
      <div style={{ display:'flex', alignItems:'center', gap:8, fontSize:11, color:'var(--fg-4)',
                    textTransform:'uppercase', letterSpacing:'.08em', fontFamily:'var(--font-mono)' }}>
        <span style={{ width:5, height:5, borderRadius:99, background: c }}/>
        {label}
      </div>
      <div style={{ fontSize: 28, fontWeight: 600, letterSpacing:'-0.02em', marginTop: 6, fontVariantNumeric:'tabular-nums' }}>{value}</div>
      <div className="muted" style={{ fontSize:11.5, marginTop: 4 }}>{sub}</div>
    </div>
  );
};

const WarningRow = ({ tone, msg, id }) => (
  <div style={{ display:'flex', gap: 10, padding:'10px 12px', borderRadius: 6,
                background: tone==='fail' ? 'var(--status-fail-soft)' : 'var(--status-run-soft)',
                border: '1px solid ' + (tone==='fail' ? 'var(--status-fail)' : 'var(--status-run)'), }}>
    <Icons.spark size={14} style={{ color: tone==='fail' ? 'var(--status-fail)' : 'var(--status-run)', marginTop: 1 }}/>
    <div style={{ flex:1 }}>
      <div style={{ fontSize: 12.5 }}>{msg}</div>
      <div className="muted mono" style={{ fontSize: 10.5, marginTop: 2 }}>{id}</div>
    </div>
    <button className="btn btn-sm btn-ghost"><Icons.x size={12}/></button>
  </div>
);

window.ChannelOpsScreen = ChannelOpsScreen;
