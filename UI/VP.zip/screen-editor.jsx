/* global React, Icons, Badge */

const { useState: useStateEd } = React;

const NODE_TYPES = [
  { cat: 'Sources',    items: [
    { t: 'AssetFetch',     ic: 'folder', desc: 'Local library' },
    { t: 'YouTubeSource',  ic: 'film',   desc: 'Pull video by URL' },
    { t: 'BilibiliSource', ic: 'film',   desc: 'Bilibili B站' },
    { t: 'PlatformSearch', ic: 'search', desc: 'Cross‑platform query' },
  ]},
  { cat: 'Media ops',  items: [
    { t: 'Trim',           ic: 'scissors', desc: 'Time‑range cut' },
    { t: 'Concat',         ic: 'layers',   desc: 'Stitch in order' },
    { t: 'Resize',         ic: 'fit',      desc: 'Aspect / scale' },
    { t: 'AutoCaption',    ic: 'caption',  desc: 'Whisper transcribe' },
    { t: 'TTSOverlay',     ic: 'music',    desc: 'XTTS narration' },
    { t: 'SmartTrim',      ic: 'wand',     desc: 'AI shot selection' },
  ]},
  { cat: 'Output',     items: [
    { t: 'Render',         ic: 'cube',    desc: 'H.264 / MP4' },
    { t: 'PublishYouTube', ic: 'globe',   desc: 'Private / unlisted' },
    { t: 'PublishXHS',     ic: 'share',   desc: 'Xiaohongshu' },
  ]},
];

const PORT_TONE = {
  video: 'video', audio: 'audio', subtitle: 'subtitle', media: 'media', any_media: 'media',
};

// Graph layout
const GRAPH_NODES = [
  { id:'n1', x: 40,  y: 80,  t:'AssetFetch',    kind:'source', status:'ok',
    ins:[], outs:[{n:'media', tone:'media'}], note:'cats_2024.mp4' },
  { id:'n2', x: 40,  y: 220, t:'PlatformSearch', kind:'source', status:'ok',
    ins:[], outs:[{n:'results', tone:'media'}], note:'youtube · bilibili · xhs' },
  { id:'n3', x: 290, y: 150, t:'RightsFilter',  kind:'gate',   status:'ok',
    ins:[{n:'media', tone:'media'}, {n:'results', tone:'media'}],
    outs:[{n:'allowed', tone:'media'}], note:'policy: owned_only' },
  { id:'n4', x: 540, y: 80,  t:'SmartTrim',     kind:'plan',   status:'ok',
    ins:[{n:'media', tone:'media'}], outs:[{n:'shots', tone:'video'}], note:'min 3 · max 8 shots' },
  { id:'n5', x: 540, y: 220, t:'AutoCaption',   kind:'media',  status:'ok',
    ins:[{n:'media', tone:'media'}], outs:[{n:'subs', tone:'subtitle'}], note:'whisper · zh+en' },
  { id:'n6', x: 790, y: 150, t:'Assemble',      kind:'render', status:'run', sel:true,
    ins:[{n:'shots', tone:'video'}, {n:'subs', tone:'subtitle'}],
    outs:[{n:'video', tone:'video'}], note:'9:16 · 30s · BGM auto' },
  { id:'n7', x:1040, y: 150, t:'Publish',       kind:'export', status:'idle',
    ins:[{n:'video', tone:'video'}], outs:[], note:'private upload · YT' },
];

const NODE_W = 188;
const portYIn  = (count, i) => 18 + 18 * i;
const portYOut = (count, i) => 18 + 18 * i;

const EditorScreen = () => {
  const [selected, setSelected] = useStateEd('n6');
  const [zoom, setZoom] = useStateEd(100);
  const [search, setSearch] = useStateEd('');

  const sel = GRAPH_NODES.find(n => n.id === selected);

  // edges between named ports
  const edges = [
    { from:'n1', fromPort:0, to:'n3', toPort:0 },
    { from:'n2', fromPort:0, to:'n3', toPort:1 },
    { from:'n3', fromPort:0, to:'n4', toPort:0, active:true },
    { from:'n3', fromPort:0, to:'n5', toPort:0, active:true },
    { from:'n4', fromPort:0, to:'n6', toPort:0, active:true },
    { from:'n5', fromPort:0, to:'n6', toPort:1, active:true },
    { from:'n6', fromPort:0, to:'n7', toPort:0 },
  ];

  return (
    <div className="editor-shell">
      {/* PALETTE */}
      <aside className="editor-aside">
        <div className="palette-search">
          <div className="wrap">
            <Icons.search className="icon" size={14} />
            <input placeholder="Search nodes…" value={search} onChange={e=>setSearch(e.target.value)} />
          </div>
        </div>
        <div style={{ overflowY:'auto', paddingBottom: 16 }}>
          {NODE_TYPES.map(group => (
            <div key={group.cat}>
              <div className="palette-cat">{group.cat}</div>
              {group.items
                .filter(it => !search || it.t.toLowerCase().includes(search.toLowerCase()))
                .map(it => (
                  <div key={it.t} className="palette-item" draggable>
                    <div className="ico">{Icons[it.ic] ? Icons[it.ic]({}) : <Icons.cube size={13}/>}</div>
                    <div>
                      <div>{it.t}</div>
                      <div className="muted" style={{ fontSize: 11 }}>{it.desc}</div>
                    </div>
                  </div>
                ))
              }
            </div>
          ))}
        </div>
      </aside>

      {/* CANVAS */}
      <div className="editor-canvas">
        {/* edges layer */}
        <svg style={{ position:'absolute', inset:0, width:'100%', height:'100%' }}>
          <defs>
            <marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto">
              <path d="M0 0 L10 5 L0 10 z" fill="#3a3a40" />
            </marker>
            <marker id="arrow-a" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto">
              <path d="M0 0 L10 5 L0 10 z" fill="var(--acc)" />
            </marker>
          </defs>
          {edges.map((e, i) => {
            const A = GRAPH_NODES.find(n=>n.id===e.from);
            const B = GRAPH_NODES.find(n=>n.id===e.to);
            const x1 = A.x + NODE_W;
            const y1 = A.y + 30 + portYOut(A.outs.length, e.fromPort);
            const x2 = B.x;
            const y2 = B.y + 30 + portYIn(B.ins.length, e.toPort);
            const mx = (x1+x2)/2;
            return (
              <path key={i}
                    d={`M${x1},${y1} C${mx},${y1} ${mx},${y2} ${x2},${y2}`}
                    fill="none"
                    stroke={e.active ? 'var(--acc)' : '#3a3a40'}
                    strokeWidth={e.active ? 2 : 1.4}
                    strokeDasharray={e.active ? '5 4' : ''}
                    markerEnd={`url(#${e.active ? 'arrow-a' : 'arrow'})`}>
                {e.active && <animate attributeName="stroke-dashoffset" from="18" to="0" dur="0.8s" repeatCount="indefinite"/>}
              </path>
            );
          })}
        </svg>

        {/* nodes */}
        {GRAPH_NODES.map(n => (
          <div key={n.id}
               className={`graph-node ${n.id===selected?'sel':''} ${n.status==='run'?'running':''} ${n.status==='ok'?'ok':''}`}
               style={{ left: n.x, top: n.y }}
               onClick={()=>setSelected(n.id)}>
            <div className="head">
              <span className="dot" style={{
                background: n.status==='run' ? 'var(--status-run)' :
                           n.status==='ok' ? 'var(--status-ok)' :
                           n.status==='fail' ? 'var(--status-fail)' : 'var(--fg-5)'
              }} />
              <span className="title">{n.t}</span>
              <span className="kind">{n.kind}</span>
            </div>
            <div className="body">{n.note}</div>
            {n.status === 'run' && (
              <div style={{ padding:'0 11px 9px' }}>
                <div className="meter warn"><div style={{ width:'62%' }} /></div>
              </div>
            )}
            <div className="footer">
              {n.id}
              <span style={{ marginLeft:'auto' }}>
                {n.status === 'run' ? '00:12 elapsed' : n.status === 'ok' ? '00:08' : 'queued'}
              </span>
            </div>
            {/* ports */}
            {n.ins.map((p, i) => (
              <span key={'in'+i} className={`port in ${PORT_TONE[p.tone]||''}`}
                    style={{ top: 30 + portYIn(n.ins.length, i) }} title={p.n}/>
            ))}
            {n.outs.map((p, i) => (
              <span key={'out'+i} className={`port out ${PORT_TONE[p.tone]||''}`}
                    style={{ top: 30 + portYOut(n.outs.length, i) }} title={p.n}/>
            ))}
          </div>
        ))}

        {/* zoom controls */}
        <div className="canvas-controls">
          <button onClick={()=>setZoom(z=>Math.max(25,z-10))}><Icons.zoomOut size={14}/></button>
          <span className="zoom">{zoom}%</span>
          <button onClick={()=>setZoom(z=>Math.min(200,z+10))}><Icons.zoom size={14}/></button>
          <span style={{ width:1, height:18, background:'var(--border-2)', margin:'0 2px' }} />
          <button title="Fit"><Icons.fit size={14}/></button>
        </div>

        {/* minimap */}
        <div className="minimap">
          <svg viewBox="0 0 1300 400" style={{ width:'100%', height:'100%' }} preserveAspectRatio="none">
            <rect x="0" y="0" width="1300" height="400" fill="rgba(196,247,74,0.02)" />
            {GRAPH_NODES.map(n=>(
              <rect key={n.id} x={n.x} y={n.y} width={NODE_W} height={56} rx={8}
                    fill="#26262a" stroke="#3a3a40" />
            ))}
            <rect x="20" y="40" width="1100" height="320" fill="none" stroke="var(--acc)" strokeWidth="3"/>
          </svg>
        </div>

        {/* legend */}
        <div style={{ position:'absolute', top:14, left:14, display:'flex', gap:14, alignItems:'center',
                      background:'rgba(15,15,18,0.85)', backdropFilter:'blur(8px)',
                      border:'1px solid var(--border-2)', borderRadius:6, padding:'6px 10px',
                      fontSize:11, fontFamily:'var(--font-mono)' }}>
          <span style={{ display:'flex', alignItems:'center', gap:6 }}><span className="port video" style={{ position:'static', width:8, height:8 }} /> video</span>
          <span style={{ display:'flex', alignItems:'center', gap:6 }}><span className="port audio" style={{ position:'static', width:8, height:8 }} /> audio</span>
          <span style={{ display:'flex', alignItems:'center', gap:6 }}><span className="port subtitle" style={{ position:'static', width:8, height:8 }} /> subtitle</span>
          <span style={{ display:'flex', alignItems:'center', gap:6 }}><span className="port media" style={{ position:'static', width:8, height:8 }} /> any_media</span>
        </div>

        {/* run bar */}
        <div style={{ position:'absolute', top:14, right:14, display:'flex', gap:8, alignItems:'center' }}>
          <span className="tag">pipeline_b41e</span>
          <span className="tag">7 nodes</span>
          <button className="btn btn-sm"><Icons.history size={12}/>Validate</button>
          <button className="btn btn-sm"><Icons.copy size={12}/>Save</button>
          <button className="btn btn-primary btn-sm"><Icons.play size={12}/>Run</button>
        </div>
      </div>

      {/* CONFIG */}
      <aside className="editor-right">
        <div className="config-head">
          <div className="title">{sel.t}</div>
          <div className="type">{sel.kind} · {sel.id}</div>
          <div style={{ display:'flex', gap:6, marginTop:8 }}>
            <Badge status={sel.status === 'run' ? 'run' : sel.status === 'ok' ? 'ok' : 'idle'}>
              {sel.status === 'run' ? 'RUNNING' : sel.status === 'ok' ? 'CACHED' : 'IDLE'}
            </Badge>
            <span className="tag">worker · gpu</span>
          </div>
        </div>

        <div className="field">
          <label>Aspect ratio</label>
          <select defaultValue="9:16">
            <option>9:16</option><option>16:9</option><option>1:1</option><option>4:5</option>
          </select>
        </div>
        <div className="field">
          <label>Target duration (s)</label>
          <div className="field-row">
            <input type="number" defaultValue={30} style={{ width: 80 }} />
            <input type="range" defaultValue={30} min={5} max={120} style={{ flex:1, accentColor:'var(--acc)' }} />
          </div>
        </div>
        <div className="field">
          <label>Background music</label>
          <select defaultValue="auto">
            <option value="auto">auto · upbeat</option>
            <option>auto · ambient</option>
            <option>none</option>
            <option>custom asset…</option>
          </select>
        </div>
        <div className="field">
          <label>Caption style</label>
          <div className="field-row">
            <select defaultValue="bold-bottom">
              <option>bold-bottom</option>
              <option>karaoke</option>
              <option>typewriter</option>
            </select>
          </div>
        </div>
        <div className="field">
          <label>Render quality</label>
          <div className="field-row">
            {['draft','standard','high'].map(q=>(
              <button key={q} className={`btn btn-sm ${q==='standard'?'btn-primary':''}`} style={{ flex:1, justifyContent:'center' }}>{q}</button>
            ))}
          </div>
        </div>
        <div className="field">
          <label>Live output</label>
          <div style={{ aspectRatio:'9/16', width:140, margin:'4px auto 0', borderRadius:6, border:'1px solid var(--border-2)',
                        background: 'linear-gradient(135deg,#1f1f25,#131316)', position:'relative', overflow:'hidden' }}>
            <div style={{ position:'absolute', inset:8, border:'1px dashed #2a2a30', borderRadius:4 }}/>
            <div style={{ position:'absolute', bottom:6, left:6, right:6, height:4, background:'rgba(0,0,0,.5)', borderRadius:2 }}>
              <div style={{ height:'100%', width:'62%', background:'var(--status-run)', borderRadius:2 }}/>
            </div>
            <div style={{ position:'absolute', top:6, right:6, fontFamily:'var(--font-mono)', fontSize:10, color:'var(--fg-2)', background:'rgba(0,0,0,.5)', padding:'1px 5px', borderRadius:3 }}>0:12 / 0:30</div>
          </div>
        </div>

        <div className="field" style={{ borderBottom: 'none' }}>
          <label>Recent runs</label>
          <div style={{ display:'flex', flexDirection:'column', gap:4 }}>
            {[
              ['j-8a3f', 'run', '14s ago'],
              ['j-7d22', 'ok',  '6m ago'],
              ['j-7c11', 'fail','22m ago'],
            ].map(([id,s,t])=>(
              <div key={id} style={{ display:'flex', alignItems:'center', gap:8, padding:'6px 8px', borderRadius:5, fontSize:12 }}>
                <Badge status={s}>{s.toUpperCase()}</Badge>
                <span className="mono dim" style={{ fontSize:11.5 }}>{id}</span>
                <span className="mono" style={{ marginLeft:'auto', fontSize:11, color:'var(--fg-4)' }}>{t}</span>
              </div>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
};

window.EditorScreen = EditorScreen;
