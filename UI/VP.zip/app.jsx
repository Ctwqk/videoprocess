/* global React, ReactDOM, Icons,
          Sidebar, AutoFlowScreen, EditorScreen, JobsScreen, JobDetailScreen, AssetsScreen, TemplatesScreen,
          TweaksPanel, TweakSection, TweakColor, TweakRadio, TweakToggle, useTweaks */

const { useState, useEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#7dd3fc",
  "density": "default",
  "theme": "dark",
  "mono_numbers": true
}/*EDITMODE-END*/;

const ACCENTS = {
  '#c4f74a': { acc2: '#a3d626', fg: '#0a0a0b' }, // lime
  '#7dd3fc': { acc2: '#38bdf8', fg: '#06141d' }, // sky
  '#f0abfc': { acc2: '#e879f9', fg: '#1a0a1d' }, // magenta
  '#fdba74': { acc2: '#fb923c', fg: '#1a0d05' }, // orange
};

const ROUTE_TITLES = {
  'autoflow':   { title: 'AutoFlow',     crumbs: ['workflow', 'autoflow'] },
  'editor':     { title: 'Pipeline editor', crumbs: ['workflow','pipeline_b41e','editor'] },
  'jobs':       { title: 'Jobs',         crumbs: ['library', 'jobs'] },
  'job-detail': { title: 'Job detail',   crumbs: ['library', 'jobs', 'j-8a3f12d4'] },
  'assets':     { title: 'Assets',       crumbs: ['library', 'assets'] },
  'templates':  { title: 'Templates',    crumbs: ['workflow', 'templates'] },
  'channelops': { title: 'ChannelOps',   crumbs: ['ops', 'channels'] },
};

const App = () => {
  const [route, setRoute] = useState('autoflow');
  const [collapsed, setCollapsed] = useState(false);
  const [activeJob, setActiveJob] = useState('j-8a3f12d4');
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Apply tweaks to CSS vars
  useEffect(() => {
    const root = document.documentElement;
    const acc = t.accent || '#c4f74a';
    const tone = ACCENTS[acc] || { acc2: acc, fg: '#0a0a0b' };
    root.style.setProperty('--acc', acc);
    root.style.setProperty('--acc-2', tone.acc2);
    root.style.setProperty('--acc-fg', tone.fg);

    // soft variants from accent hex
    const hex = acc.replace('#','');
    const r = parseInt(hex.slice(0,2),16);
    const g = parseInt(hex.slice(2,4),16);
    const b = parseInt(hex.slice(4,6),16);
    root.style.setProperty('--acc-soft', `rgba(${r}, ${g}, ${b}, 0.14)`);
    root.style.setProperty('--acc-soft-2', `rgba(${r}, ${g}, ${b}, 0.06)`);

    root.setAttribute('data-density', t.density);
    root.setAttribute('data-theme', t.theme);

    // light theme overrides
    if (t.theme === 'light') {
      const map = {
        '--bg-0': '#fafaf9',
        '--bg-1': '#ffffff',
        '--bg-2': '#f5f5f4',
        '--bg-3': '#ececea',
        '--bg-elev': '#ffffff',
        '--border-1': '#e7e5e4',
        '--border-2': '#d6d3d1',
        '--border-3': '#a8a29e',
        '--fg-1': '#0c0a09',
        '--fg-2': '#1c1917',
        '--fg-3': '#57534e',
        '--fg-4': '#78716c',
        '--fg-5': '#a8a29e',
      };
      Object.entries(map).forEach(([k,v]) => root.style.setProperty(k, v));
    } else {
      const dark = {
        '--bg-0': '#09090b','--bg-1': '#0d0d10','--bg-2': '#131316','--bg-3': '#1a1a1f','--bg-elev': '#1f1f25',
        '--border-1': '#1f1f23','--border-2': '#27272a','--border-3': '#3f3f46',
        '--fg-1': '#fafafa','--fg-2': '#d4d4d8','--fg-3': '#a1a1aa','--fg-4': '#71717a','--fg-5': '#52525b',
      };
      Object.entries(dark).forEach(([k,v]) => root.style.setProperty(k, v));
    }
  }, [t.accent, t.density, t.theme, t.mono_numbers]);

  // keyboard shortcuts
  useEffect(() => {
    const fn = (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      const map = { '1':'autoflow', '2':'editor', '3':'templates', '4':'jobs', '5':'assets', '6':'channelops' };
      if (map[e.key]) { setRoute(map[e.key]); e.preventDefault(); }
      if ((e.metaKey || e.ctrlKey) && e.key === '\\') { setCollapsed(c=>!c); e.preventDefault(); }
    };
    window.addEventListener('keydown', fn);
    return () => window.removeEventListener('keydown', fn);
  }, []);

  const r = ROUTE_TITLES[route] || { title: route, crumbs: [] };

  return (
    <div className="shell">
      <Sidebar route={route} setRoute={setRoute} collapsed={collapsed} setCollapsed={setCollapsed} />
      <div className="main">
        <header className="topbar">
          <div className="topbar-title">
            <h1>{r.title}</h1>
            {r.crumbs.map((c,i)=>(
              <span key={i} className="topbar-crumb">{c}</span>
            ))}
          </div>
          <div className="topbar-spacer" />
          <div className="topbar-actions">
            <button className="btn btn-sm btn-ghost"><Icons.search size={13}/>Search<Kbd>⌘K</Kbd></button>
            <button className="btn btn-icon btn-ghost"><Icons.bell size={14}/></button>
            <span style={{ width:1, height: 22, background:'var(--border-1)', margin:'0 4px' }} />
            <div style={{ display:'flex', alignItems:'center', gap:8 }}>
              <div style={{ width:24, height:24, borderRadius:'50%', background:'linear-gradient(135deg, var(--acc), var(--acc-2))',
                            display:'grid', placeItems:'center', fontSize:11, fontWeight:700, color:'var(--acc-fg)' }}>T</div>
              <span style={{ fontSize: 13 }}>tom</span>
            </div>
          </div>
        </header>

        {route === 'autoflow'   && <AutoFlowScreen setRoute={setRoute} setActiveJob={setActiveJob} />}
        {route === 'editor'     && <EditorScreen />}
        {route === 'jobs'       && <JobsScreen setRoute={setRoute} setActiveJob={setActiveJob} />}
        {route === 'job-detail' && <JobDetailScreen jobId={activeJob} setRoute={setRoute} />}
        {route === 'assets'     && <AssetsScreen />}
        {route === 'templates'  && <TemplatesScreen setRoute={setRoute} />}
        {route === 'channelops' && <ChannelOpsScreen />}
      </div>

      <TweaksPanel title="Tweaks">
        <TweakSection title="Accent">
          <TweakColor label="Brand color"
            value={t.accent}
            onChange={v => setTweak('accent', v)}
            options={['#c4f74a', '#7dd3fc', '#f0abfc', '#fdba74']} />
        </TweakSection>
        <TweakSection title="Theme">
          <TweakRadio label="Mode"
            value={t.theme}
            options={[{value:'dark', label:'Dark'},{value:'light', label:'Light'}]}
            onChange={v => setTweak('theme', v)} />
        </TweakSection>
        <TweakSection title="Density">
          <TweakRadio label="Row spacing"
            value={t.density}
            options={[
              {value:'compact', label:'Compact'},
              {value:'default', label:'Default'},
              {value:'comfortable', label:'Comfy'},
            ]}
            onChange={v => setTweak('density', v)} />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
};

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
