/* global React, Icons, Badge, StatusForJob */

const { useState: useStateJ } = React;

const JOBS = [
  { id: 'j-8a3f12d4', pipeline: 'AutoFlow · cat compilation', status:'RUNNING',   submitted:'2m ago',  dur:'01:22', progress:62, nodes:'5/8', cost:'$0.12', who:'autoflow' },
  { id: 'j-7d22a911', pipeline: 'Smart trim · podcast cut',   status:'SUCCEEDED', submitted:'14m ago', dur:'02:47', progress:100, nodes:'9/9', cost:'$0.31', who:'tom' },
  { id: 'j-7c11ea8e', pipeline: 'Whisper · interview',        status:'SUCCEEDED', submitted:'1h ago',  dur:'04:18', progress:100, nodes:'4/4', cost:'$0.08', who:'tom' },
  { id: 'j-7b09c5f0', pipeline: 'AutoFlow · product demo',    status:'FAILED',    submitted:'2h ago',  dur:'00:34', progress:38, nodes:'3/8', cost:'$0.04', who:'autoflow' },
  { id: 'j-7a91bb22', pipeline: 'Resize batch · 36 clips',    status:'PARTIALLY_FAILED', submitted:'5h ago', dur:'12:09', progress:91, nodes:'33/36', cost:'$0.61', who:'tom' },
  { id: 'j-6f17de9c', pipeline: 'Publish · YouTube Shorts',   status:'SUCCEEDED', submitted:'Yesterday', dur:'00:46', progress:100, nodes:'2/2', cost:'$0.02', who:'tom' },
  { id: 'j-6e02bc34', pipeline: 'AutoFlow · travel vlog',     status:'CANCELLED', submitted:'Yesterday', dur:'00:11', progress:6, nodes:'0/12', cost:'$0.00', who:'tom' },
  { id: 'j-6d44a91a', pipeline: 'Caption + TTS overlay',      status:'SUCCEEDED', submitted:'2 days ago', dur:'01:55', progress:100, nodes:'5/5', cost:'$0.14', who:'tom' },
  { id: 'j-6b91cc77', pipeline: 'Storyboard preview render',  status:'PENDING',   submitted:'queued', dur:'—', progress:0, nodes:'0/7', cost:'$0.00', who:'autoflow' },
];

const JobsScreen = ({ setRoute, setActiveJob }) => {
  const [filter, setFilter] = useStateJ('all');
  const filtered = JOBS.filter(j => filter === 'all' || j.status.toLowerCase() === filter);

  const stats = {
    running: JOBS.filter(j=>j.status==='RUNNING').length,
    queued: JOBS.filter(j=>j.status==='PENDING').length,
    ok: JOBS.filter(j=>j.status==='SUCCEEDED').length,
    fail: JOBS.filter(j=>['FAILED','PARTIALLY_FAILED'].includes(j.status)).length,
  };

  return (
    <div className="page">
      <div style={{ padding: '20px 24px 0' }}>
        {/* stat strip */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:12, marginBottom:18 }}>
          <Stat label="Running" value={stats.running} tone="run" sub="2 nodes active" />
          <Stat label="Queued"  value={stats.queued}  tone="queue" sub="GPU runner-01 free" />
          <Stat label="Succeeded (24h)" value={stats.ok} tone="ok" sub="100% rights cleared" />
          <Stat label="Failed (24h)" value={stats.fail} tone="fail" sub="1 timeout · 1 partial" />
        </div>

        <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:10 }}>
          <div style={{ display:'flex', gap:4, padding: 3, background:'var(--bg-1)', border:'1px solid var(--border-1)', borderRadius: 7 }}>
            {[
              ['all','All', JOBS.length],
              ['running','Running', stats.running],
              ['pending','Queued', stats.queued],
              ['succeeded','Succeeded', stats.ok],
              ['failed','Failed', JOBS.filter(j=>j.status==='FAILED').length],
            ].map(([k,l,n])=>(
              <button key={k} className="btn btn-sm" onClick={()=>setFilter(k)}
                      style={{
                        background: filter===k ? 'var(--bg-3)' : 'transparent',
                        border: '1px solid ' + (filter===k ? 'var(--border-2)' : 'transparent'),
                        color: filter===k ? 'var(--fg-1)' : 'var(--fg-3)',
                      }}>
                {l} <span className="mono dim" style={{ marginLeft:6, fontSize:10.5 }}>{n}</span>
              </button>
            ))}
          </div>
          <div style={{ flex:1 }} />
          <div style={{ position:'relative' }}>
            <Icons.search size={13} style={{ position:'absolute', left:9, top:'50%', transform:'translateY(-50%)', color:'var(--fg-4)' }} />
            <input placeholder="Filter…" style={{ width: 220, paddingLeft: 28 }} />
          </div>
          <button className="btn btn-sm"><Icons.history size={12}/>Auto‑refresh · 5s</button>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '0 24px 24px' }}>
        <table className="table">
          <thead>
            <tr>
              <th style={{ width: 130 }}>Job ID</th>
              <th>Pipeline</th>
              <th style={{ width: 110 }}>Status</th>
              <th style={{ width: 180 }}>Progress</th>
              <th style={{ width: 100 }}>Duration</th>
              <th style={{ width: 110 }}>Submitted</th>
              <th style={{ width: 70 }}>Cost</th>
              <th style={{ width: 60 }}></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(j => {
              const s = StatusForJob(j.status);
              return (
                <tr key={j.id} onClick={()=>{ setActiveJob(j.id); setRoute('job-detail'); }} style={{ cursor:'pointer' }}>
                  <td className="id">{j.id}</td>
                  <td>
                    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                      {j.who==='autoflow'
                        ? <Icons.spark size={13} style={{ color:'var(--acc)' }} />
                        : <Icons.flow size={13} style={{ color:'var(--fg-4)' }} />}
                      <span className="row-link">{j.pipeline}</span>
                    </div>
                  </td>
                  <td><Badge status={s.tone}>{s.label}</Badge></td>
                  <td>
                    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                      <div className={`meter ${s.tone==='ok'?'ok':s.tone==='run'?'warn':s.tone==='fail'?'fail':''}`} style={{ flex:1 }}>
                        <div style={{ width: j.progress+'%' }} />
                      </div>
                      <span className="mono dim" style={{ fontSize:11, width: 44, textAlign:'right' }}>{j.nodes}</span>
                    </div>
                  </td>
                  <td className="mono dim" style={{ fontSize: 12 }}>{j.dur}</td>
                  <td className="mono dim" style={{ fontSize: 12 }}>{j.submitted}</td>
                  <td className="mono" style={{ fontSize: 12 }}>{j.cost}</td>
                  <td className="actions"><button className="btn btn-icon btn-ghost"><Icons.more size={14}/></button></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const Stat = ({ label, value, tone, sub }) => {
  const toneColor = { ok:'var(--status-ok)', run:'var(--status-run)', fail:'var(--status-fail)', queue:'var(--status-queue)' }[tone];
  return (
    <div className="card" style={{ padding: '14px 18px' }}>
      <div style={{ display:'flex', alignItems:'center', gap:8, fontSize:11, color:'var(--fg-4)',
                    textTransform:'uppercase', letterSpacing:'.08em', fontFamily:'var(--font-mono)' }}>
        <span style={{ width:5, height:5, borderRadius:99, background: toneColor }}/>
        {label}
      </div>
      <div style={{ fontSize: 28, fontWeight: 600, letterSpacing:'-0.02em', marginTop: 6, fontVariantNumeric:'tabular-nums' }}>{value}</div>
      <div className="muted" style={{ fontSize:11.5, marginTop: 4 }}>{sub}</div>
    </div>
  );
};

window.JobsScreen = JobsScreen;
