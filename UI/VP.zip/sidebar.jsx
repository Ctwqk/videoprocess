/* global React, Icons */

const NavItem = ({ icon: I, label, kbd, active, collapsed, onClick }) => (
  <div className={`nav-item ${active ? 'active' : ''}`} onClick={onClick} title={collapsed ? label : undefined}>
    <I className="nav-icon" size={16} />
    <span>{label}</span>
    {kbd ? <span className="nav-kbd">{kbd}</span> : null}
  </div>
);

const PlatformChip = ({ short, label, state = 'ok', meta, collapsed }) => {
  const colors = { ok: 'var(--status-ok)', warn: 'var(--status-run)', err: 'var(--status-fail)' };
  return (
    <div className="platform-chip" title={collapsed ? label : undefined}>
      <span className="dot" style={{ background: colors[state] }} />
      <span className="label">{label}</span>
      {meta && <span className="meta">{meta}</span>}
    </div>
  );
};

const Sidebar = ({ route, setRoute, collapsed, setCollapsed }) => {
  return (
    <aside className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
      <div className="brand">
        <div className="brand-mark">V</div>
        {!collapsed && <>
          <div className="brand-name">VideoProcess</div>
          <div className="brand-tag">v0.4</div>
        </>}
      </div>

      <div className="nav">
        {!collapsed && <div className="nav-section">Workflow</div>}
        <NavItem icon={Icons.spark}  label="AutoFlow"  kbd="1" active={route==='autoflow'}  collapsed={collapsed} onClick={()=>setRoute('autoflow')} />
        <NavItem icon={Icons.flow}   label="Editor"    kbd="2" active={route==='editor'}    collapsed={collapsed} onClick={()=>setRoute('editor')} />
        <NavItem icon={Icons.layers} label="Templates" kbd="3" active={route==='templates'} collapsed={collapsed} onClick={()=>setRoute('templates')} />

        {!collapsed && <div className="nav-section">Library</div>}
        <NavItem icon={Icons.play}   label="Jobs"      kbd="4" active={route==='jobs' || route==='job-detail'} collapsed={collapsed} onClick={()=>setRoute('jobs')} />
        <NavItem icon={Icons.folder} label="Assets"    kbd="5" active={route==='assets'}    collapsed={collapsed} onClick={()=>setRoute('assets')} />
        <NavItem icon={Icons.branch} label="ChannelOps" kbd="6" active={route==='channelops'} collapsed={collapsed} onClick={()=>setRoute('channelops')} />

        {!collapsed && <div className="nav-section">Platforms</div>}
        <div style={{ display:'flex', flexDirection:'column', gap:2, padding: collapsed ? 0 : '0 0 0 0' }}>
          <PlatformChip short="YT"   label="YouTube"     state="ok"   meta="connected" collapsed={collapsed} />
          <PlatformChip short="XHS"  label="Xiaohongshu" state="ok"   meta="connected" collapsed={collapsed} />
          <PlatformChip short="BILI" label="Bilibili"    state="warn" meta="reauth"    collapsed={collapsed} />
          <PlatformChip short="X"    label="X"           state="err"  meta="offline"   collapsed={collapsed} />
        </div>
      </div>

      <div className="sidebar-footer">
        <div className="platform-chip" style={{ pointerEvents:'none' }}>
          <span className="dot" style={{ background: 'var(--acc)' }} />
          {!collapsed && <>
            <span className="label">runner-01</span>
            <span className="meta">2/4 GPU</span>
          </>}
        </div>
        <div className="nav-item" onClick={()=>setCollapsed(!collapsed)} style={{ justifyContent: collapsed?'center':'space-between', cursor: 'pointer' }}>
          <Icons.panelLeft className="nav-icon" size={16} />
          {!collapsed && <span style={{ flex:1 }}>Collapse</span>}
          {!collapsed && <span className="nav-kbd">⌘\</span>}
        </div>
      </div>
    </aside>
  );
};

window.Sidebar = Sidebar;
