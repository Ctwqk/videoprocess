/* global React, Icons, Badge */

const JOB_NODES = [
  { i: 1, t:'AssetFetch',     type:'source', status:'ok',  dur:'0.8s',  art: 'cats_2024.mp4' },
  { i: 2, t:'PlatformSearch', type:'source', status:'ok',  dur:'12.4s', art: '23 candidates' },
  { i: 3, t:'RightsFilter',   type:'gate',   status:'ok',  dur:'1.2s',  art: '18/23 allowed' },
  { i: 4, t:'SmartTrim',      type:'plan',   status:'ok',  dur:'9.6s',  art: '6 shots selected' },
  { i: 5, t:'AutoCaption',    type:'media',  status:'run', dur:'00:12', progress: 62, art: 'whisper · 62%' },
  { i: 6, t:'Assemble',       type:'render', status:'queue', dur:'—', art: 'queued · gpu pending' },
  { i: 7, t:'Render',         type:'render', status:'queue', dur:'—', art: 'queued' },
  { i: 8, t:'PublishYouTube', type:'export', status:'queue', dur:'—', art: 'queued · private' },
];

const LOGS = [
  ['12:04:01.022','info','autoflow', 'plan plan_2f9c v3 created'],
  ['12:04:01.187','info','runner-01','job j-8a3f12d4 submitted'],
  ['12:04:02.014','info','AssetFetch','fetched cats_2024.mp4 · 184MB'],
  ['12:04:14.401','info','PlatformSearch','youtube=14 bilibili=6 xhs=3'],
  ['12:04:15.612','info','RightsFilter','allowed=18 blocked=2 review=3'],
  ['12:04:25.230','info','SmartTrim','model=cv-shotrank shots=6'],
  ['12:04:25.402','info','AutoCaption','whisper-large-v3 · zh+en'],
  ['12:05:18.901','warn','AutoCaption','low-confidence segment 0:14-0:16'],
];

const JobDetailScreen = ({ jobId, setRoute }) => {
  return (
    <div className="page">
      <div style={{ padding: '20px 24px 0' }}>
        <div style={{ display:'flex', alignItems:'center', gap:14, marginBottom:14 }}>
          <button className="btn btn-sm btn-ghost" onClick={()=>setRoute('jobs')}>
            <Icons.chevron size={12} style={{ transform:'rotate(180deg)' }}/> Jobs
          </button>
          <h2 style={{ margin:0, fontSize: 20, letterSpacing:'-0.02em', fontWeight:600 }}>
            AutoFlow · cat compilation
          </h2>
          <span className="tag mono">{jobId}</span>
          <Badge status="run">RUNNING</Badge>
          <div style={{ flex:1 }}/>
          <button className="btn btn-sm"><Icons.history size={12}/>Replay</button>
          <button className="btn btn-sm"><Icons.copy size={12}/>Clone</button>
          <button className="btn btn-sm btn-danger"><Icons.x size={12}/>Cancel</button>
        </div>

        {/* progress strip */}
        <div className="card" style={{ padding: '14px 18px', marginBottom: 16 }}>
          <div style={{ display:'flex', alignItems:'center', gap:14 }}>
            <div style={{ flex:1 }}>
              <div style={{ display:'flex', justifyContent:'space-between', fontSize:11.5, marginBottom:6 }}>
                <span className="muted mono" style={{ textTransform:'uppercase', letterSpacing:'.06em' }}>Overall progress</span>
                <span className="mono num">62%  ·  5/8 nodes  ·  elapsed 01:22  ·  ETA 00:54</span>
              </div>
              <div className="meter warn" style={{ height: 8 }}><div style={{ width:'62%' }}/></div>
            </div>
          </div>
          <div style={{ display:'flex', gap:6, marginTop:14 }}>
            {JOB_NODES.map(n => (
              <div key={n.i} title={n.t} style={{
                flex: 1, height: 22,
                background: n.status==='ok' ? 'var(--status-ok-soft)' : n.status==='run' ? 'var(--status-run-soft)' : 'var(--bg-2)',
                border: '1px solid ' + (n.status==='ok' ? 'var(--status-ok)' : n.status==='run' ? 'var(--status-run)' : 'var(--border-2)'),
                borderRadius: 4,
                position:'relative',
                display:'grid', placeItems:'center',
                fontSize: 10, fontFamily:'var(--font-mono)',
                color: n.status==='ok' ? 'var(--status-ok)' : n.status==='run' ? 'var(--status-run)' : 'var(--fg-4)',
              }}>
                {n.t.slice(0,9)}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="job-grid" style={{ paddingTop:0 }}>
        {/* timeline */}
        <div>
          <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:10 }}>
            <h3 style={{ margin:0, fontSize:13, fontWeight:600, color:'var(--fg-2)' }}>Node executions</h3>
            <span className="tag mono">{JOB_NODES.length}</span>
            <div style={{ flex:1 }}/>
            <button className="btn btn-sm btn-ghost"><Icons.list size={12}/>Filter</button>
          </div>

          <div className="timeline">
            {JOB_NODES.map(n => (
              <div key={n.i} className={`tl-node ${n.status==='run'?'running':''}`}>
                <div className={`tl-mark ${n.status}`}>
                  {n.status==='ok' ? <Icons.check size={13}/> :
                   n.status==='run' ? <Icons.play size={11}/> :
                   n.status==='fail' ? <Icons.x size={13}/> :
                   String(n.i).padStart(2,'0')}
                </div>
                <div>
                  <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                    <span className="tl-title">{n.t}</span>
                    <span className="tag" style={{ fontSize: 10 }}>{n.type}</span>
                    {n.status==='run' && <span style={{ display:'inline-flex', alignItems:'center', gap:4, fontSize:11, color:'var(--status-run)' }}><span className="pulse" style={{ width:5, height:5 }}/>live</span>}
                  </div>
                  <div className="tl-sub">{n.art}</div>
                  {n.progress != null && (
                    <div className="tl-bar run" style={{ marginTop: 8 }}><div style={{ width: n.progress+'%' }}/></div>
                  )}
                </div>
                <div className="tl-meta">
                  <div>{n.dur}</div>
                  <div className="dim" style={{ fontSize:10.5, marginTop:2 }}>{n.status==='ok' ? 'completed' : n.status==='run' ? 'running' : 'queued'}</div>
                </div>
              </div>
            ))}
          </div>

          {/* logs */}
          <div className="card" style={{ marginTop: 18 }}>
            <div className="section-head">
              <h3>Log stream</h3>
              <span className="count">live · last 50 lines</span>
              <div className="spacer"/>
              <button className="btn btn-sm btn-ghost"><Icons.download size={12}/>Export</button>
            </div>
            <div style={{ padding: '4px 0 12px', maxHeight: 220, overflowY:'auto' }}>
              {LOGS.map((l, i) => (
                <div key={i} style={{ padding: '4px 20px', fontFamily:'var(--font-mono)', fontSize: 11.5,
                                       display:'grid', gridTemplateColumns:'120px 50px 130px 1fr', gap: 10,
                                       borderTop: i===0 ? 'none' : '1px solid var(--border-1)',
                                       color: l[1]==='warn' ? 'var(--status-run)' : 'var(--fg-3)' }}>
                  <span className="dim">{l[0]}</span>
                  <span style={{ color: l[1]==='warn' ? 'var(--status-run)' : 'var(--fg-4)', textTransform:'uppercase' }}>{l[1]}</span>
                  <span className="dim">{l[2]}</span>
                  <span style={{ color:'var(--fg-2)' }}>{l[3]}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* sidebar */}
        <aside>
          <div className="card">
            <div className="section-head"><h3>Final artifact</h3></div>
            <div style={{ padding: '0 20px 20px' }}>
              <div style={{ aspectRatio:'9/16', width: '100%', maxWidth: 200, margin:'0 auto',
                            borderRadius: 8, border:'1px solid var(--border-2)',
                            background:'linear-gradient(135deg,#1f1f25,#131316)', position:'relative', overflow:'hidden' }}>
                <div style={{ position:'absolute', inset:10, border:'1px dashed #2a2a30', borderRadius:5 }}/>
                <div style={{ position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)' }}>
                  <Icons.play size={32} style={{ color:'var(--fg-3)' }}/>
                </div>
                <div style={{ position:'absolute', bottom:6, left:6, right:6, height:3, background:'rgba(0,0,0,.5)', borderRadius:2 }}>
                  <div style={{ height:'100%', width:'62%', background:'var(--status-run)', borderRadius:2 }}/>
                </div>
              </div>
              <div style={{ marginTop: 14, display:'flex', gap:6, flexDirection:'column', fontSize:11.5 }}>
                <KvRow k="resolution" v="1080 × 1920" />
                <KvRow k="duration"  v="0:30.00" />
                <KvRow k="bitrate"   v="8.4 Mbps" />
                <KvRow k="size"      v="—" subtle />
                <KvRow k="status"    v="rendering" tone="run" />
              </div>
              <div style={{ display:'flex', gap:6, marginTop:12 }}>
                <button className="btn btn-sm" disabled style={{ flex:1, justifyContent:'center' }}><Icons.download size={12}/>Download</button>
                <button className="btn btn-sm" disabled style={{ flex:1, justifyContent:'center' }}><Icons.share size={12}/>Publish</button>
              </div>
            </div>
          </div>

          <div className="card" style={{ marginTop: 14 }}>
            <div className="section-head"><h3>Plan reference</h3></div>
            <dl className="kv-grid" style={{ paddingBottom: 16 }}>
              <dt>plan</dt><dd className="mono">plan_2f9c</dd>
              <dt>intent</dt><dd>cat compilation · cute fast‑paced</dd>
              <dt>policy</dt><dd>owned_only</dd>
              <dt>publish</dt><dd><Badge status="queue">private_upload</Badge></dd>
              <dt>approved</dt><dd>tom@local · 12:03:54</dd>
              <dt>cost so far</dt><dd className="mono num">$0.12 / est $0.18</dd>
            </dl>
          </div>

          <div className="card" style={{ marginTop: 14 }}>
            <div className="section-head"><h3>Resources</h3></div>
            <div style={{ padding:'0 20px 16px', display:'flex', flexDirection:'column', gap:10 }}>
              <ResourceRow label="GPU runner-01" used="2 / 4 streams" pct={50} tone="run" />
              <ResourceRow label="CPU workers"   used="3 / 8 slots"   pct={37} tone="ok" />
              <ResourceRow label="Disk · staging" used="42 / 200 GB"   pct={21} tone="ok" />
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
};

const KvRow = ({ k, v, subtle, tone }) => (
  <div style={{ display:'flex', justifyContent:'space-between', gap:10 }}>
    <span className="dim mono" style={{ fontSize: 10.5, textTransform:'uppercase', letterSpacing:'.05em' }}>{k}</span>
    {tone
      ? <Badge status={tone}>{v}</Badge>
      : <span className={`mono ${subtle?'dim':''}`} style={{ fontSize: 12 }}>{v}</span>}
  </div>
);

const ResourceRow = ({ label, used, pct, tone }) => (
  <div>
    <div style={{ display:'flex', justifyContent:'space-between', fontSize:11.5 }}>
      <span>{label}</span>
      <span className="mono dim">{used}</span>
    </div>
    <div className={`meter ${tone==='run'?'warn':tone==='fail'?'fail':'ok'}`} style={{ marginTop: 5 }}>
      <div style={{ width: pct+'%' }}/>
    </div>
  </div>
);

window.JobDetailScreen = JobDetailScreen;
